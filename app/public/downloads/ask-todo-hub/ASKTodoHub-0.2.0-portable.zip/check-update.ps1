﻿[CmdletBinding()]
param(
  [string]$CurrentVersion,
  [string]$ManifestUrl = "https://harness-meeting-app.kibayerin.workers.dev/downloads/ask-todo-hub/version-manifest.json",
  [switch]$AsJson
)

$ErrorActionPreference = "Stop"
$hubRoot = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
if ([string]::IsNullOrWhiteSpace($CurrentVersion)) {
  $installedManifest = Join-Path $hubRoot "version-manifest.json"
  if (-not (Test-Path -LiteralPath $installedManifest -PathType Leaf)) {
    throw "CurrentVersion is required when version-manifest.json is not installed beside this script."
  }
  $CurrentVersion = [string](Get-Content -Raw -Encoding UTF8 -LiteralPath $installedManifest | ConvertFrom-Json).version
}

if ($CurrentVersion -notmatch '^\d+\.\d+\.\d+$') { throw "CurrentVersion must use x.y.z format: $CurrentVersion" }
$manifestUri = $null
if (-not [Uri]::TryCreate($ManifestUrl, [UriKind]::Absolute, [ref]$manifestUri) -or $manifestUri.Scheme -ne "https") {
  throw "ManifestUrl must be an absolute HTTPS URL."
}

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$headers = @{ "User-Agent" = "ASKTodoHub-read-only-update-check"; "Accept" = "application/json" }
$manifest = Invoke-RestMethod -Method Get -Uri $manifestUri.AbsoluteUri -Headers $headers
if ([int]$manifest.schemaVersion -ne 1 -or [string]$manifest.product -ne "ASKTodoHub") {
  throw "Unexpected update manifest identity."
}
$latestVersion = [string]$manifest.version
if ($latestVersion -notmatch '^\d+\.\d+\.\d+$') { throw "Latest manifest version is not x.y.z: $latestVersion" }

$result = [ordered]@{
  manifestUrl = $manifestUri.AbsoluteUri
  currentVersion = $CurrentVersion
  latestVersion = $latestVersion
  updateAvailable = ([version]$latestVersion -gt [version]$CurrentVersion)
  downloadBaseUrl = [string]$manifest.downloadBaseUrl
  checkedAtUtc = [DateTime]::UtcNow.ToString("o")
  actionTaken = "none"
}

if ($AsJson) {
  $result | ConvertTo-Json -Depth 3
} else {
  Write-Host ("Current: {0}" -f $result.currentVersion)
  Write-Host ("Latest:  {0}" -f $result.latestVersion)
  Write-Host ("Update available: {0}" -f $result.updateAvailable)
  Write-Host ("Downloads: {0}" -f $result.downloadBaseUrl)
  Write-Host "Read-only check completed. Nothing was downloaded or installed."
}
