﻿<#
  asktodo-gui.ps1  (ASK/Todo 관리 GUI — Phase 3)

  registry.json 에 등록된 프로젝트를 WinForms 목록으로 관리한다.
  등록/해제는 asktodo-register.ps1 을 재사용하고, 캡처 실행은 asktodo-capture.ps1 을 호출한다.
#>
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

function Resolve-HubRoot {
  if ($PSScriptRoot) { return (Resolve-Path -LiteralPath $PSScriptRoot).Path }
  if ($PSCommandPath) { return (Split-Path -Parent (Resolve-Path -LiteralPath $PSCommandPath).Path) }
  return (Get-Location).Path
}

$script:HubRoot = Resolve-HubRoot
$script:RegistryPath = Join-Path $script:HubRoot "registry.json"
$script:RegisterScript = Join-Path $script:HubRoot "asktodo-register.ps1"
$script:CaptureScript = Join-Path $script:HubRoot "asktodo-capture.ps1"
$script:DashboardScript = Join-Path $script:HubRoot "asktodo-dashboard.ps1"
$script:DashboardSyncScript = Join-Path $script:HubRoot "asktodo-dashboard-sync.ps1"
$script:ProjectsScript = Join-Path $script:HubRoot "asktodo-projects.ps1"
$script:SessionScript = Join-Path $script:HubRoot "asktodo-session.ps1"
$script:DashboardIndex = Join-Path $script:HubRoot "dashboard\index.html"
$script:Grid = $null
$script:NoPublishCheck = $null

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic
[System.Windows.Forms.Application]::EnableVisualStyles()

function Read-Registry {
  if (Test-Path $script:RegistryPath) {
    try {
      $obj = Get-Content -Raw -Encoding UTF8 -LiteralPath $script:RegistryPath | ConvertFrom-Json
      $projects = @()
      if ($obj.projects) { $projects = @($obj.projects) }
      $version = if ($obj.version) { [int]$obj.version } else { 1 }
      return [pscustomobject]@{ version = $version; installMode = $obj.installMode; projects = $projects }
    } catch {
      [System.Windows.Forms.MessageBox]::Show("registry.json 파싱 실패: $($_.Exception.Message)", "ASK/Todo", "OK", "Warning") | Out-Null
    }
  }
  return [pscustomobject]@{ version = 2; installMode = "personal"; projects = @() }
}

function Get-HubMode {
  $registry = Read-Registry
  if ($registry.installMode -eq "temporary") { return "temporary" }
  return "personal"
}

function Set-HubMode([string]$Mode) {
  try {
    $action = if ($Mode -eq "temporary") { "set-temporary" } else { "set-personal" }
    & $script:SessionScript -Action $action | Out-Null
    $statusLabel.Text = "Hub: $script:HubRoot | Mode: $Mode"
    Show-Message $(if ($Mode -eq "temporary") { "임시 PC 모드입니다. 영구 예약 작업을 만들지 않습니다." } else { "개인 PC 모드입니다. 등록 시 Windows 예약 작업을 만듭니다." })
  } catch { Show-Error $_.Exception.Message }
}

function Get-TaskState([string]$taskName) {
  if ([string]::IsNullOrWhiteSpace($taskName)) { return "(없음)" }
  if (-not (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue)) { return "(확인 불가)" }
  try {
    $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if ($task) { return $task.State.ToString() }
  } catch {}
  return "(태스크 없음)"
}

function Get-ProjectLogId([pscustomobject]$project) {
  if ($project.id) { return [string]$project.id }
  if ($project.path) {
    return ([Convert]::ToBase64String(([Text.Encoding]::UTF8.GetBytes(([string]$project.path).ToLowerInvariant())))).TrimEnd('=').Replace('+','-').Replace('/','_')
  }
  return [string]$project.name
}

function Get-ProjectLogPath([pscustomobject]$project, [string]$Extension = ".log") {
  $logId = Get-ProjectLogId $project
  return Join-Path $script:HubRoot ("logs\{0}{1}" -f $logId, $Extension)
}

function Read-ProjectStatus([pscustomobject]$project) {
  $logId = Get-ProjectLogId $project
  $statusPath = Join-Path $script:HubRoot ("logs\{0}.status.json" -f $logId)
  if (-not (Test-Path -LiteralPath $statusPath)) { return $null }
  try { return Get-Content -Raw -Encoding UTF8 -LiteralPath $statusPath | ConvertFrom-Json } catch { return $null }
}

function Test-ProjectPaused([string]$path) {
  if (-not (Test-Path -LiteralPath $path)) { return $false }
  return (Test-Path -LiteralPath (Join-Path $path ".ask_paused")) -or
         (Test-Path -LiteralPath (Join-Path $path "scripts\.claude_ask_paused"))
}

function Get-MarkdownStats([string]$dir) {
  if (-not (Test-Path -LiteralPath $dir)) {
    return [pscustomobject]@{ Count = 0; Latest = "" }
  }
  $files = @(Get-ChildItem -LiteralPath $dir -Filter "*.md" -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -ne "README.md" } |
    Sort-Object LastWriteTime -Descending)
  $latest = ""
  if ($files.Count -gt 0) { $latest = $files[0].Name }
  return [pscustomobject]@{ Count = $files.Count; Latest = $latest }
}

function New-ProjectTable {
  $table = New-Object System.Data.DataTable
  foreach ($name in @("Name", "Tool", "Times", "Task", "Paused", "ASK", "Todo", "LatestASK", "LastRun", "Capture", "Publish", "ExitCode", "Exists", "Path")) {
    [void]$table.Columns.Add($name)
  }

  $reg = Read-Registry
  foreach ($p in @($reg.projects)) {
    $path = [string]$p.path
    $exists = Test-Path -LiteralPath $path
    $ask = Get-MarkdownStats (Join-Path $path "ASK")
    $todo = Get-MarkdownStats (Join-Path $path "Todo")
    $paused = if (Test-ProjectPaused $path) { "YES" } else { "" }
    $status = Read-ProjectStatus $p
    $row = $table.NewRow()
    $row["Name"] = [string]$p.name
    $row["Tool"] = [string]$p.tool
    $row["Times"] = if ($p.times) { @($p.times) -join ", " } else { [string]$p.time }
    $row["Task"] = Get-TaskState ([string]$p.taskName)
    $row["Paused"] = $paused
    $row["LastRun"] = if ($status -and $status.lastRunAt) { [DateTime]::Parse($status.lastRunAt).ToString("MM-dd HH:mm") } else { "" }
    $row["Capture"] = if ($status -and $status.capture -and $status.capture.status) { [string]$status.capture.status } else { "" }
    $row["Publish"] = if ($status -and $status.publish -and $status.publish.status) { [string]$status.publish.status } else { "" }
    $row["ExitCode"] = if ($status -and $status.exitCode -ne $null) { [string]$status.exitCode } else { "" }
    $row["ASK"] = [string]$ask.Count
    $row["Todo"] = [string]$todo.Count
    $row["LatestASK"] = $ask.Latest
    $row["Exists"] = if ($exists) { "YES" } else { "NO" }
    $row["Path"] = $path
    [void]$table.Rows.Add($row)
  }
  return $table
}

function Refresh-Grid {
  $script:Grid.DataSource = $null
  $script:Grid.DataSource = New-ProjectTable
  foreach ($col in $script:Grid.Columns) { $col.AutoSizeMode = "AllCells" }
  $script:Grid.Columns["Path"].AutoSizeMode = "Fill"
}

function Get-SelectedProject {
  if (-not $script:Grid.CurrentRow) { return $null }
  $path = [string]$script:Grid.CurrentRow.Cells["Path"].Value
  if ([string]::IsNullOrWhiteSpace($path)) { return $null }
  $reg = Read-Registry
  return @($reg.projects | Where-Object { $_.path -eq $path } | Select-Object -First 1)
}

function Show-Message([string]$message, [string]$title = "ASK/Todo") {
  [System.Windows.Forms.MessageBox]::Show($message, $title, "OK", "Information") | Out-Null
}

function Show-Error([string]$message) {
  [System.Windows.Forms.MessageBox]::Show($message, "ASK/Todo 오류", "OK", "Error") | Out-Null
}

function Confirm-Action([string]$message) {
  $result = [System.Windows.Forms.MessageBox]::Show($message, "ASK/Todo 확인", "YesNo", "Question")
  return $result -eq [System.Windows.Forms.DialogResult]::Yes
}

function Open-Path([string]$path) {
  if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path)) {
    Show-Error "경로가 없습니다: $path"
    return
  }
  Start-Process -FilePath $path | Out-Null
}

function Show-ProjectDialog($Project = $null) {
  $dialog = New-Object System.Windows.Forms.Form
  $dialog.Text = if ($Project) { "프로젝트 편집" } else { "프로젝트 등록" }
  $dialog.StartPosition = "CenterParent"
  $dialog.Size = New-Object System.Drawing.Size(620, 210)
  $dialog.FormBorderStyle = "FixedDialog"
  $dialog.MaximizeBox = $false
  $dialog.MinimizeBox = $false

  $pathLabel = New-Object System.Windows.Forms.Label
  $pathLabel.Text = "RepoRoot"
  $pathLabel.Location = New-Object System.Drawing.Point(16, 22)
  $pathLabel.AutoSize = $true

  $pathBox = New-Object System.Windows.Forms.TextBox
  $pathBox.Location = New-Object System.Drawing.Point(92, 18)
  $pathBox.Size = New-Object System.Drawing.Size(400, 24)
  if ($Project) { $pathBox.Text = [string]$Project.path; $pathBox.ReadOnly = $true }

  $browse = New-Object System.Windows.Forms.Button
  $browse.Text = "찾기"
  $browse.Location = New-Object System.Drawing.Point(500, 16)
  $browse.Size = New-Object System.Drawing.Size(80, 28)
  if ($Project) { $browse.Enabled = $false }

  $toolLabel = New-Object System.Windows.Forms.Label
  $toolLabel.Text = "Tool"
  $toolLabel.Location = New-Object System.Drawing.Point(16, 66)
  $toolLabel.AutoSize = $true

  $toolBox = New-Object System.Windows.Forms.ComboBox
  $toolBox.Location = New-Object System.Drawing.Point(92, 62)
  $toolBox.Size = New-Object System.Drawing.Size(160, 24)
  $toolBox.DropDownStyle = "DropDownList"
  [void]$toolBox.Items.AddRange(@("claude", "codex", "both"))
  $toolBox.SelectedItem = "claude"
  if ($Project -and $Project.tool) { $toolBox.SelectedItem = [string]$Project.tool }

  $timeLabel = New-Object System.Windows.Forms.Label
  $timeLabel.Text = "Times"
  $timeLabel.Location = New-Object System.Drawing.Point(292, 66)
  $timeLabel.AutoSize = $true

  $timesBox = New-Object System.Windows.Forms.TextBox
  $timesBox.Location = New-Object System.Drawing.Point(342, 62)
  $timesBox.Size = New-Object System.Drawing.Size(238, 24)
  $timesBox.Text = if ($Project -and $Project.times) { @($Project.times) -join ", " } elseif ($Project -and $Project.time) { [string]$Project.time } else { "17:30" }

  $ok = New-Object System.Windows.Forms.Button
  $ok.Text = if ($Project) { "저장" } else { "등록" }
  $ok.Location = New-Object System.Drawing.Point(400, 120)
  $ok.Size = New-Object System.Drawing.Size(80, 30)
  $ok.DialogResult = [System.Windows.Forms.DialogResult]::OK

  $cancel = New-Object System.Windows.Forms.Button
  $cancel.Text = "취소"
  $cancel.Location = New-Object System.Drawing.Point(500, 120)
  $cancel.Size = New-Object System.Drawing.Size(80, 30)
  $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel

  $browse.Add_Click({
    $folder = New-Object System.Windows.Forms.FolderBrowserDialog
    $folder.Description = "ASK/Todo 자동화에 등록할 git 저장소를 선택하세요."
    if ($folder.ShowDialog($dialog) -eq [System.Windows.Forms.DialogResult]::OK) {
      $pathBox.Text = $folder.SelectedPath
    }
  })

  $dialog.AcceptButton = $ok
  $dialog.CancelButton = $cancel
  [void]$dialog.Controls.AddRange(@($pathLabel, $pathBox, $browse, $toolLabel, $toolBox, $timeLabel, $timesBox, $ok, $cancel))

  if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return $null }
  if ([string]::IsNullOrWhiteSpace($pathBox.Text)) {
    Show-Error "RepoRoot 를 선택하세요."
    return $null
  }
  if ([string]::IsNullOrWhiteSpace($timesBox.Text)) {
    Show-Error "실행 시각을 HH:mm 형식으로 하나 이상 입력하세요. 예: 09:00, 13:00, 17:30"
    return $null
  }
  return [pscustomobject]@{
    Path = $pathBox.Text.Trim()
    Tool = [string]$toolBox.SelectedItem
    Times = $timesBox.Text.Trim()
  }
}

function Invoke-RegisterProject {
  $info = Show-ProjectDialog
  if (-not $info) { return }
  try {
    & $script:RegisterScript -Action add -RepoRoot $info.Path -Tool $info.Tool -Times $info.Times -InstallMode (Get-HubMode) | Out-Null
    Refresh-Grid
    Show-Message "등록했습니다: $($info.Path)"
  } catch {
    Show-Error $_.Exception.Message
  }
}

function Invoke-EditProject {
  $project = Get-SelectedProject
  if (-not $project) { Show-Error "편집할 프로젝트를 선택하세요."; return }
  $info = Show-ProjectDialog $project
  if (-not $info) { return }
  try {
    & $script:RegisterScript -Action add -RepoRoot $info.Path -Tool $info.Tool -Times $info.Times -InstallMode (Get-HubMode) | Out-Null
    Refresh-Grid
    Show-Message "수정했습니다: $($info.Path)"
  } catch {
    Show-Error $_.Exception.Message
  }
}

function Show-MultiProjectDialog {
  $dialog = New-Object System.Windows.Forms.Form
  $dialog.Text = "여러 프로젝트 추가"
  $dialog.StartPosition = "CenterParent"
  $dialog.Size = New-Object System.Drawing.Size(760, 500)

  $parentLabel = New-Object Windows.Forms.Label
  $parentLabel.Text = "상위 폴더 검색 (깊이 2)"
  $parentLabel.Location = New-Object Drawing.Point(16, 18)
  $parentLabel.AutoSize = $true
  $parentBox = New-Object Windows.Forms.TextBox
  $parentBox.Location = New-Object Drawing.Point(16, 42)
  $parentBox.Size = New-Object Drawing.Size(560, 24)
  $browseParent = New-Object Windows.Forms.Button
  $browseParent.Text = "찾기"
  $browseParent.Location = New-Object Drawing.Point(588, 40)
  $browseParent.Size = New-Object Drawing.Size(64, 28)
  $scan = New-Object Windows.Forms.Button
  $scan.Text = "검색"
  $scan.Location = New-Object Drawing.Point(660, 40)
  $scan.Size = New-Object Drawing.Size(64, 28)

  $pathsLabel = New-Object Windows.Forms.Label
  $pathsLabel.Text = "등록할 Git 폴더 (한 줄에 하나, drag & drop 또는 붙여넣기)"
  $pathsLabel.Location = New-Object Drawing.Point(16, 82)
  $pathsLabel.AutoSize = $true
  $pathsBox = New-Object Windows.Forms.TextBox
  $pathsBox.Location = New-Object Drawing.Point(16, 106)
  $pathsBox.Size = New-Object Drawing.Size(708, 238)
  $pathsBox.Multiline = $true
  $pathsBox.ScrollBars = "Both"
  $pathsBox.AllowDrop = $true
  $pathsBox.Add_DragEnter({ if ($_.Data.GetDataPresent([Windows.Forms.DataFormats]::FileDrop)) { $_.Effect = "Copy" } })
  $pathsBox.Add_DragDrop({ $pathsBox.Lines = @($pathsBox.Lines + @($_.Data.GetData([Windows.Forms.DataFormats]::FileDrop))) })

  $toolLabel = New-Object Windows.Forms.Label
  $toolLabel.Text = "Tool"
  $toolLabel.Location = New-Object Drawing.Point(16, 364)
  $toolLabel.AutoSize = $true
  $toolBox = New-Object Windows.Forms.ComboBox
  $toolBox.Location = New-Object Drawing.Point(62, 360)
  $toolBox.Size = New-Object Drawing.Size(130, 24)
  $toolBox.DropDownStyle = "DropDownList"
  [void]$toolBox.Items.AddRange(@("claude", "codex", "both"))
  $toolBox.SelectedItem = "claude"
  $timesLabel = New-Object Windows.Forms.Label
  $timesLabel.Text = "Times"
  $timesLabel.Location = New-Object Drawing.Point(220, 364)
  $timesLabel.AutoSize = $true
  $timesBox = New-Object Windows.Forms.TextBox
  $timesBox.Location = New-Object Drawing.Point(274, 360)
  $timesBox.Size = New-Object Drawing.Size(220, 24)
  $timesBox.Text = "17:30"

  $ok = New-Object Windows.Forms.Button
  $ok.Text = "일괄 등록"
  $ok.Location = New-Object Drawing.Point(548, 404)
  $ok.Size = New-Object Drawing.Size(86, 30)
  $ok.DialogResult = [Windows.Forms.DialogResult]::OK
  $cancel = New-Object Windows.Forms.Button
  $cancel.Text = "취소"
  $cancel.Location = New-Object Drawing.Point(642, 404)
  $cancel.Size = New-Object Drawing.Size(82, 30)
  $cancel.DialogResult = [Windows.Forms.DialogResult]::Cancel

  $browseParent.Add_Click({
    $folder = New-Object Windows.Forms.FolderBrowserDialog
    if ($folder.ShowDialog($dialog) -eq [Windows.Forms.DialogResult]::OK) { $parentBox.Text = $folder.SelectedPath }
  })
  $scan.Add_Click({
    try {
      $found = @(& $script:ProjectsScript -Action scan -ParentPath $parentBox.Text -MaxDepth 2)
      $pathsBox.Lines = @($found | ForEach-Object { $_.path })
      Show-Message "$($found.Count)개 Git 저장소를 찾았습니다."
    } catch { Show-Error $_.Exception.Message }
  })

  [void]$dialog.Controls.AddRange(@($parentLabel, $parentBox, $browseParent, $scan, $pathsLabel, $pathsBox, $toolLabel, $toolBox, $timesLabel, $timesBox, $ok, $cancel))
  $dialog.AcceptButton = $ok
  $dialog.CancelButton = $cancel
  if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { return $null }
  $selectedPaths = @($pathsBox.Lines | ForEach-Object { $_.Trim() } | Where-Object { $_ })
  if (-not $selectedPaths.Count) { Show-Error "등록할 폴더를 하나 이상 입력하세요."; return $null }
  return [pscustomobject]@{ Paths = $selectedPaths; Tool = [string]$toolBox.SelectedItem; Times = $timesBox.Text.Trim() }
}

function Invoke-RegisterManyProjects {
  $info = Show-MultiProjectDialog
  if (-not $info) { return }
  try {
    $temporary = (Get-HubMode) -eq "temporary"
    $results = @(& $script:ProjectsScript -Action add-many -Paths $info.Paths -Tool $info.Tool -Times $info.Times -Temporary:$temporary)
    Refresh-Grid
    $success = @($results | Where-Object { $_.ok }).Count
    $failed = @($results | Where-Object { -not $_.ok })
    $details = @($failed | ForEach-Object { "$($_.input): $($_.reason)" }) -join "`r`n"
    Show-Message "등록 성공: $success / 실패: $($failed.Count)$(if ($details) { "`r`n`r`n$details" })"
  } catch { Show-Error $_.Exception.Message }
}

function Invoke-CloneProject {
  $url = [Microsoft.VisualBasic.Interaction]::InputBox("GitHub HTTPS 또는 SSH URL", "GitHub 저장소 clone", "https://github.com/owner/repo")
  if ([string]::IsNullOrWhiteSpace($url)) { return }
  $folder = New-Object Windows.Forms.FolderBrowserDialog
  $folder.Description = "clone 대상 상위 폴더를 선택하세요. 기존 폴더는 덮어쓰지 않습니다."
  if ($folder.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { return }
  try {
    $temporary = (Get-HubMode) -eq "temporary"
    $cloned = & $script:ProjectsScript -Action clone -RepoUrl $url -DestinationRoot $folder.SelectedPath -Temporary:$temporary
    & $script:RegisterScript -Action add -RepoRoot $cloned.path -Tool claude -Times "17:30" -InstallMode $(if ($temporary) { "temporary" } else { "personal" }) | Out-Null
    Refresh-Grid
    Show-Message "clone 및 등록 완료: $($cloned.path)"
  } catch { Show-Error $_.Exception.Message }
}

function Invoke-TemporaryCleanup {
  try {
    $plan = @(& $script:SessionScript -Action cleanup)
    if (-not $plan.Count) { Show-Message "정리할 임시 프로젝트가 없습니다."; return }
    $summary = @($plan | ForEach-Object { "$($_.name): registry 제거, clone 제거=$($_.removeOwnedClone), log 제거=$($_.removeLog)" }) -join "`r`n"
    if (-not (Confirm-Action "다음 Hub 소유 임시 리소스를 정리할까요?`r`n`r`n$summary")) { return }
    & $script:SessionScript -Action cleanup -Execute | Out-Null
    Refresh-Grid
    Show-Message "임시 리소스 정리가 완료되었습니다. Git credential/browser session은 시스템 안내에 따라 별도로 확인하세요."
  } catch { Show-Error $_.Exception.Message }
}

function Invoke-RemoveProject {
  $project = Get-SelectedProject
  if (-not $project) { Show-Error "해제할 프로젝트를 선택하세요."; return }
  if (-not (Confirm-Action "스케줄과 registry 에서 '$($project.name)' 을 제거할까요? ASK/Todo 데이터는 보존됩니다.")) { return }
  try {
    & $script:RegisterScript -Action remove -RepoRoot $project.path | Out-Null
    Refresh-Grid
    Show-Message "해제했습니다: $($project.name)"
  } catch {
    Show-Error $_.Exception.Message
  }
}

function Invoke-CaptureProject {
  $project = Get-SelectedProject
  if (-not $project) { Show-Error "캡처할 프로젝트를 선택하세요."; return }
  $tool = [string]$project.tool
  if ([string]::IsNullOrWhiteSpace($tool)) { $tool = "claude" }
  try {
    $args = @{ RepoRoot = $project.path; Tool = $tool }
    if ($script:NoPublishCheck.Checked) { $args.NoPublish = $true }
    & $script:CaptureScript @args | Out-Null
    Refresh-Grid
    Show-Message "캡처 실행이 끝났습니다: $($project.name)"
  } catch {
    Show-Error $_.Exception.Message
  }
}

function Set-Paused {
  param([bool]$Paused)
  $project = Get-SelectedProject
  if (-not $project) { Show-Error "프로젝트를 선택하세요."; return }
  $flag = Join-Path $project.path ".ask_paused"
  try {
    if ($Paused) {
      if (-not (Test-Path -LiteralPath $flag)) {
        New-Item -ItemType File -Path $flag -Force | Out-Null
      }
    } else {
      if (Test-Path -LiteralPath $flag) {
        Remove-Item -LiteralPath $flag -Force
      }
    }
    Refresh-Grid
  } catch {
    Show-Error $_.Exception.Message
  }
}

function Invoke-Dashboard {
  try {
    if (-not (Test-Path -LiteralPath $script:DashboardScript)) {
      Show-Error "대시보드 스크립트가 없습니다: $script:DashboardScript"
      return
    }
    & $script:DashboardScript | Out-Null
    Refresh-Grid
    Open-Path $script:DashboardIndex
  } catch {
    Show-Error $_.Exception.Message
  }
}

function Invoke-DashboardSync {
  try {
    if (-not (Test-Path -LiteralPath $script:DashboardSyncScript)) {
      Show-Error "동기화 스크립트가 없습니다: $script:DashboardSyncScript"
      return
    }
    $syncArgs = @("-UploadMethod", "auto")
    if ([Environment]::GetEnvironmentVariable("ASKTODO_DASHBOARD_PAGES_PROJECT")) {
      $syncArgs += @("-PagesProject", [Environment]::GetEnvironmentVariable("ASKTODO_DASHBOARD_PAGES_PROJECT"))
    }
    if ([Environment]::GetEnvironmentVariable("ASKTODO_DASHBOARD_UPLOAD_URL")) {
      $syncArgs += @("-UploadUrl", [Environment]::GetEnvironmentVariable("ASKTODO_DASHBOARD_UPLOAD_URL"))
    }
    if (-not [Environment]::GetEnvironmentVariable("ASKTODO_DASHBOARD_UPLOAD_URL") -and
        -not [Environment]::GetEnvironmentVariable("ASKTODO_DASHBOARD_PAGES_PROJECT")) {
      $syncArgs += @("-NoUpload")
    }
    & $script:DashboardSyncScript @syncArgs | Out-Null
    Refresh-Grid
    Show-Message "등록 재생성 + 대시보드 동기화가 끝났습니다."
  } catch {
    Show-Error $_.Exception.Message
  }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "ASK/Todo Hub"
$form.StartPosition = "CenterScreen"
$form.Size = New-Object System.Drawing.Size(1120, 680)
$form.MinimumSize = New-Object System.Drawing.Size(960, 560)

$top = New-Object System.Windows.Forms.FlowLayoutPanel
$top.Dock = "Top"
$top.Height = 92
$top.Padding = New-Object System.Windows.Forms.Padding(10)
$top.WrapContents = $true

function New-Button([string]$text, [int]$width = 92) {
  $button = New-Object System.Windows.Forms.Button
  $button.Text = $text
  $button.Width = $width
  $button.Height = 30
  return $button
}

$addButton = New-Button "등록"
$addManyButton = New-Button "여러 개 추가" 112
$cloneButton = New-Button "GitHub clone" 112
$personalModeButton = New-Button "개인 PC" 92
$temporaryModeButton = New-Button "임시 PC" 92
$cleanupButton = New-Button "임시 정리" 92
$editButton = New-Button "편집"
$removeButton = New-Button "해제"
$refreshButton = New-Button "새로고침"
$captureButton = New-Button "캡처 실행" 104
$pauseButton = New-Button "보류"
$resumeButton = New-Button "재개"
$openProjectButton = New-Button "프로젝트 열기" 112
$openAskButton = New-Button "ASK 열기"
$openLogButton = New-Button "로그 열기"
$dashboardButton = New-Button "대시보드" 104
$dashboardSyncButton = New-Button "일괄 동기화" 118

$script:NoPublishCheck = New-Object System.Windows.Forms.CheckBox
$script:NoPublishCheck.Text = "캡처 실행 시 발행 생략"
$script:NoPublishCheck.Width = 170
$script:NoPublishCheck.Height = 30
$script:NoPublishCheck.Checked = $true

[void]$top.Controls.AddRange(@(
  $personalModeButton, $temporaryModeButton, $cleanupButton, $addButton, $addManyButton, $cloneButton, $editButton, $removeButton, $refreshButton, $captureButton, $script:NoPublishCheck,
  $pauseButton, $resumeButton, $openProjectButton, $openAskButton, $openLogButton, $dashboardButton, $dashboardSyncButton
))

$script:Grid = New-Object System.Windows.Forms.DataGridView
$script:Grid.Dock = "Fill"
$script:Grid.ReadOnly = $true
$script:Grid.SelectionMode = "FullRowSelect"
$script:Grid.MultiSelect = $false
$script:Grid.AllowUserToAddRows = $false
$script:Grid.AllowUserToDeleteRows = $false
$script:Grid.AutoGenerateColumns = $true

$status = New-Object System.Windows.Forms.StatusStrip
$statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$statusLabel.Text = "Hub: $script:HubRoot | Mode: $(Get-HubMode)"
[void]$status.Items.Add($statusLabel)

$addButton.Add_Click({ Invoke-RegisterProject })
$addManyButton.Add_Click({ Invoke-RegisterManyProjects })
$cloneButton.Add_Click({ Invoke-CloneProject })
$personalModeButton.Add_Click({ Set-HubMode "personal" })
$temporaryModeButton.Add_Click({ Set-HubMode "temporary" })
$cleanupButton.Add_Click({ Invoke-TemporaryCleanup })
$editButton.Add_Click({ Invoke-EditProject })
$removeButton.Add_Click({ Invoke-RemoveProject })
$refreshButton.Add_Click({ Refresh-Grid })
$captureButton.Add_Click({ Invoke-CaptureProject })
$pauseButton.Add_Click({ Set-Paused -Paused $true })
$resumeButton.Add_Click({ Set-Paused -Paused $false })
$openProjectButton.Add_Click({
  $project = Get-SelectedProject
  if ($project) { Open-Path $project.path } else { Show-Error "프로젝트를 선택하세요." }
})
$openAskButton.Add_Click({
  $project = Get-SelectedProject
  if ($project) { Open-Path (Join-Path $project.path "ASK") } else { Show-Error "프로젝트를 선택하세요." }
})
$openLogButton.Add_Click({
  $project = Get-SelectedProject
  if ($project) {
    $idLog = Get-ProjectLogPath $project ".log"
    if (Test-Path -LiteralPath $idLog) {
      Open-Path $idLog
    } else {
      $legacyLog = Join-Path $script:HubRoot ("logs\{0}.log" -f (Split-Path -Leaf $project.path))
      Open-Path $legacyLog
    }
  } else { Show-Error "프로젝트를 선택하세요." }
})
$dashboardButton.Add_Click({ Invoke-Dashboard })
$dashboardSyncButton.Add_Click({ Invoke-DashboardSync })

[void]$form.Controls.Add($script:Grid)
[void]$form.Controls.Add($top)
[void]$form.Controls.Add($status)

Refresh-Grid
[void][System.Windows.Forms.Application]::Run($form)
