﻿<#
  install-recognition.ps1  (ASK/Todo 인식 — Phase 5)

  이 PC의 Claude/Codex 가 어떤 대화에서든 ASK/Todo 규칙을 인식하도록 3곳에 설치한다.
  멱등(idempotent): 이미 설치돼 있으면 건너뛰거나 스킬만 갱신한다.

    1) ~/.claude/skills/ask-todo/SKILL.md      (Claude 전역 스킬 — 항상 최신본으로 덮어씀)
    2) ~/.claude/CLAUDE.md                      (짧은 포인터 — 마커 없으면 append)
    3) ~/.codex/AGENTS.md                       (규칙 전문 — 마커 없으면 append)

  다른 PC 적용: 이 저장소(ask-todo-hub)를 clone 한 뒤 이 스크립트를 1회 실행.

  옵션:
    -WhatIf : 실제로 쓰지 않고 무엇을 할지만 출력
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param()

$ErrorActionPreference = "Stop"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

$here    = $PSScriptRoot                       # .../ask-todo-hub/recognition
$home_   = $env:USERPROFILE
$marker  = "ask-todo-recognition"
$utf8    = New-Object System.Text.UTF8Encoding($false)   # BOM 없는 UTF-8

function Write-Utf8NoBom([string]$Path, [string]$Content) {
  $dir = Split-Path -Parent $Path
  if ($dir -and -not (Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
  [System.IO.File]::WriteAllText($Path, $Content, $utf8)
}

# 1) Claude 스킬 — 항상 최신본으로 갱신
$skillSrc = Join-Path $here "claude-skill\SKILL.md"
$skillDst = Join-Path $home_ ".claude\skills\ask-todo\SKILL.md"
if (Test-Path $skillSrc) {
  if ($PSCmdlet.ShouldProcess($skillDst, "Claude 스킬 설치/갱신")) {
    $dstDir = Split-Path -Parent $skillDst
    if (-not (Test-Path $dstDir)) { New-Item -ItemType Directory -Force -Path $dstDir | Out-Null }
    Copy-Item $skillSrc $skillDst -Force
    Write-Host "[OK] Claude 스킬: $skillDst"
  }
} else {
  Write-Warning "스킬 소스 없음: $skillSrc"
}

# 2) ~/.claude/CLAUDE.md — 마커 없으면 포인터 append
$claudeMd = Join-Path $home_ ".claude\CLAUDE.md"
$claudeSnippet = Get-Content -Raw -LiteralPath (Join-Path $here "claude-CLAUDE-snippet.md")
if (Test-Path $claudeMd) {
  $cur = Get-Content -Raw -LiteralPath $claudeMd
  if ($cur -match [regex]::Escape($marker)) {
    Write-Host "[skip] CLAUDE.md 이미 설치됨"
  } elseif ($PSCmdlet.ShouldProcess($claudeMd, "CLAUDE.md 포인터 append")) {
    Write-Utf8NoBom $claudeMd ($cur.TrimEnd() + "`r`n" + $claudeSnippet.TrimEnd() + "`r`n")
    Write-Host "[OK] CLAUDE.md 포인터 추가"
  }
} elseif ($PSCmdlet.ShouldProcess($claudeMd, "CLAUDE.md 생성")) {
  Write-Utf8NoBom $claudeMd ("# User Memory`r`n`r`nInstructions here apply to all projects.`r`n`r`n## Preferences`r`n" + $claudeSnippet.TrimEnd() + "`r`n")
  Write-Host "[OK] CLAUDE.md 생성"
}

# 3) ~/.codex/AGENTS.md — 마커 없으면 규칙 전문 append
$agentsMd = Join-Path $home_ ".codex\AGENTS.md"
$codexSnippet = Get-Content -Raw -LiteralPath (Join-Path $here "codex-AGENTS-snippet.md")
if (Test-Path $agentsMd) {
  $cur = Get-Content -Raw -LiteralPath $agentsMd
  if ($cur -match [regex]::Escape($marker)) {
    Write-Host "[skip] AGENTS.md 이미 설치됨"
  } elseif ($PSCmdlet.ShouldProcess($agentsMd, "AGENTS.md 규칙 append")) {
    $head = if ([string]::IsNullOrWhiteSpace($cur)) { "# AGENTS.md — Codex 전역 규칙`r`n`r`n" } else { $cur.TrimEnd() + "`r`n`r`n" }
    Write-Utf8NoBom $agentsMd ($head + $codexSnippet.TrimEnd() + "`r`n")
    Write-Host "[OK] AGENTS.md 규칙 추가"
  }
} elseif ($PSCmdlet.ShouldProcess($agentsMd, "AGENTS.md 생성")) {
  Write-Utf8NoBom $agentsMd ("# AGENTS.md — Codex 전역 규칙`r`n`r`n" + $codexSnippet.TrimEnd() + "`r`n")
  Write-Host "[OK] AGENTS.md 생성"
}

Write-Host ""
Write-Host "[DONE] ASK/Todo 인식 설치 완료. 새 Claude/Codex 대화부터 적용됩니다."
