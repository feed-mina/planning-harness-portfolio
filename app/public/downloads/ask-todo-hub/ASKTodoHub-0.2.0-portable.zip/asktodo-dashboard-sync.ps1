﻿<#
  asktodo-dashboard-sync.ps1  (registry based bulk rebuild + dashboard sync)

  Rebuild task registrations from registry.json, generate dashboard files,
  and sync dashboard/mirror to Worker/static targets.
#>
[CmdletBinding()]
param(
  [ValidateSet("auto", "pages", "http", "none")][string]$UploadMethod = "auto",
  [ValidateSet("PUT", "POST", "AUTO")][string]$UploadHttpMethod = "PUT",
  [string]$PagesProject,
  [string]$PagesBranch = "main",
  [string]$UploadUrl,
  [string]$UploadAuth,
  [string]$UploadAuthHeader = "Authorization",
  [string]$UploadPrefix = "ask-todo-hub",
  [string]$StagingRoot,
  [string]$RegistryPath,
  [switch]$SkipRebuild,
  [switch]$NoDashboard,
  [switch]$NoUpload,
  [switch]$KeepStaging,
  [switch]$OpenDashboard,
  [int]$MaxUploadFiles = 2000
)

$ErrorActionPreference = "Stop"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

function Resolve-HubRoot {
  if ($PSScriptRoot) { return (Resolve-Path -LiteralPath $PSScriptRoot).Path }
  if ($PSCommandPath) { return (Split-Path -Parent (Resolve-Path -LiteralPath $PSCommandPath).Path) }
  return (Get-Location).Path
}

$hubRoot = Resolve-HubRoot
$registerScript = Join-Path $hubRoot "asktodo-register.ps1"
$dashboardScript = Join-Path $hubRoot "asktodo-dashboard.ps1"
$dashboardIndex = Join-Path $hubRoot "dashboard\index.html"
$dashboardSource = Join-Path $hubRoot "dashboard"
$mirrorSource = Join-Path $hubRoot "mirror"
$registryPath = if ($RegistryPath) { $RegistryPath } else { Join-Path $hubRoot "registry.json" }
if (-not $StagingRoot) { $StagingRoot = Join-Path $hubRoot ".tmp\asktodo-dashboard-sync" }
$stagingDashboard = Join-Path $StagingRoot "dashboard"
$stagingMirror = Join-Path $stagingRoot "mirror"

$UploadMethod = $UploadMethod.ToLowerInvariant()
$effectiveUploadMethod = $UploadMethod

if (-not $PagesProject) { $PagesProject = [Environment]::GetEnvironmentVariable("ASKTODO_DASHBOARD_PAGES_PROJECT") }
if (-not $UploadUrl) { $UploadUrl = [Environment]::GetEnvironmentVariable("ASKTODO_DASHBOARD_UPLOAD_URL") }
if (-not $UploadAuth) { $UploadAuth = [Environment]::GetEnvironmentVariable("ASKTODO_DASHBOARD_UPLOAD_TOKEN") }

function Write-Status {
  param([string]$message)
  Write-Host "[$((Get-Date).ToString('HH:mm:ss'))] $message"
}

function Get-RegistryProjectCount {
  if (-not (Test-Path -LiteralPath $registryPath)) { return 0 }
  try {
    $obj = Get-Content -Raw -Encoding UTF8 -LiteralPath $registryPath | ConvertFrom-Json
    return @($obj.projects).Count
  } catch {
    throw "Failed to parse registry.json: $($_.Exception.Message)"
  }
}

function Invoke-RebuildTasks {
  if (-not (Test-Path -LiteralPath $registerScript)) {
    throw "register script not found: $registerScript"
  }
  if (-not (Test-Path -LiteralPath $registryPath)) {
    throw "registry.json not found: $registryPath"
  }
  $count = Get-RegistryProjectCount
  if ($count -le 0) {
    Write-Status "registry.json has no projects; skip rebuild."
    return
  }
  Write-Status ("1/3 task rebuild start ({0} projects): asktodo-register.ps1 -Action rebuild-tasks" -f $count)
  & $registerScript -Action rebuild-tasks
  Write-Status "1/3 task rebuild complete"
}

function Invoke-BuildDashboard {
  if (-not (Test-Path -LiteralPath $dashboardScript)) {
    throw "dashboard script not found: $dashboardScript"
  }
  Write-Status "2/3 dashboard build start"
  & $dashboardScript
  Write-Status "2/3 dashboard build complete"
}

function New-Staging {
  if (Test-Path -LiteralPath $StagingRoot) {
    Remove-Item -LiteralPath $StagingRoot -Recurse -Force -ErrorAction SilentlyContinue
  }
  New-Item -ItemType Directory -Force -Path $StagingRoot | Out-Null
  New-Item -ItemType Directory -Force -Path $stagingDashboard | Out-Null
  New-Item -ItemType Directory -Force -Path $stagingMirror | Out-Null

  if (Test-Path -LiteralPath $dashboardSource) {
    Get-ChildItem -LiteralPath $dashboardSource -Force | ForEach-Object {
      Copy-Item -LiteralPath $_.FullName -Destination $stagingDashboard -Recurse -Force
    }
    Write-Status ("dashboard prepared: {0}" -f $dashboardSource)
  } else {
    throw "dashboard folder not found: $dashboardSource"
  }

  if (Test-Path -LiteralPath $mirrorSource) {
    Get-ChildItem -LiteralPath $mirrorSource -Force | ForEach-Object {
      Copy-Item -LiteralPath $_.FullName -Destination $stagingMirror -Recurse -Force
    }
    Write-Status ("mirror prepared: {0}" -f $mirrorSource)
  } else {
    Write-Status "mirror folder not found, skipped."
  }
}

function Get-FileListForUpload {
  if (-not (Test-Path -LiteralPath $StagingRoot)) {
    throw "staging path not found: $StagingRoot"
  }
  return @(Get-ChildItem -LiteralPath $StagingRoot -Recurse -File -ErrorAction SilentlyContinue | Sort-Object FullName)
}

function Resolve-UploadUrl {
  param([string]$relative)
  if (-not $UploadUrl) { throw "UploadUrl is required." }
  $base = $UploadUrl.Trim().TrimEnd('/')
  $rawRelative = $relative.TrimStart('\','/')
  if ([string]::IsNullOrWhiteSpace($rawRelative)) {
    if ($UploadPrefix) { return ("{0}/{1}" -f $base, $UploadPrefix.Trim('/')) }
    return $base
  }
  $parts = [regex]::Split($rawRelative, "[\\/]")
  $safeParts = @()
  foreach ($part in @($parts | Where-Object { $_ -ne "" })) {
    if ([string]::IsNullOrWhiteSpace($part)) { continue }
    $safeParts += [uri]::EscapeDataString($part)
  }
  $path = $safeParts -join '/'
  if ($UploadPrefix) { $path = ($UploadPrefix.Trim().TrimEnd('/') + '/' + $path).TrimStart('/') }
  return ("{0}/{1}" -f $base, $path)
}

function Get-WranglerCommand {
  $wrangler = Get-Command wrangler -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($wrangler) {
    return [PSCustomObject]@{
      Path = $wrangler.Source
      IsNpx = $false
    }
  }

  $npx = Get-Command npx -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $npx) {
    throw "wrangler command not found. Install wrangler or ensure Node/npm is installed."
  }
  $npxDir = Split-Path $npx.Source
  $npxCmdPath = Join-Path $npxDir "npx.cmd"
  if (Test-Path $npxCmdPath) {
    return [PSCustomObject]@{
      Path = $npxCmdPath
      IsNpx = $true
    }
  }

  return [PSCustomObject]@{
    Path = $npx.Source
    IsNpx = $true
  }
}

function Invoke-PagesDeploy {
  $wrangler = Get-WranglerCommand
  if (-not $PagesProject) {
    throw "Pages project name missing. Set -PagesProject or ASKTODO_DASHBOARD_PAGES_PROJECT."
  }

  $files = Get-FileListForUpload
  if (-not $files.Count) { throw "No files to upload." }

  # Deploy the dashboard folder itself, not its parent, so index.html lands at the
  # site root instead of being served from /dashboard/.
  if (-not (Test-Path -LiteralPath $stagingDashboard)) {
    throw "staging dashboard path not found: $stagingDashboard"
  }
  $deployRoot = $stagingDashboard

  # Pin the production branch. Without this wrangler infers the local git branch,
  # and any branch other than the project's production branch deploys as a preview
  # (leaving the root <project>.pages.dev with no production deployment).
  $pageArgs = @("pages", "deploy", $deployRoot, "--project-name", $PagesProject, "--branch", $PagesBranch, "--commit-dirty=true")
  if ($wrangler.IsNpx) { $pageArgs = @("wrangler") + $pageArgs }

  Write-Status ("3/3 Worker deploy (Pages): {0}, branch={1}, files={2}" -f $PagesProject, $PagesBranch, $files.Count)

  $previous = $ErrorActionPreference
  try {
    $ErrorActionPreference = "Continue"
    $out = & $wrangler.Path @pageArgs 2>&1
    $exit = $LASTEXITCODE
  } finally {
    $ErrorActionPreference = $previous
  }

  if ($exit -ne 0) {
    $tokenSet = -not [string]::IsNullOrWhiteSpace([Environment]::GetEnvironmentVariable("CLOUDFLARE_API_TOKEN", "Process")) -or -not [string]::IsNullOrWhiteSpace([Environment]::GetEnvironmentVariable("CLOUDFLARE_API_TOKEN", "User")) -or -not [string]::IsNullOrWhiteSpace([Environment]::GetEnvironmentVariable("CLOUDFLARE_API_TOKEN", "Machine"))
    $accountId = [Environment]::GetEnvironmentVariable("CLOUDFLARE_ACCOUNT_ID", "Process")
    if ([string]::IsNullOrWhiteSpace($accountId)) { $accountId = [Environment]::GetEnvironmentVariable("CLOUDFLARE_ACCOUNT_ID", "User") }
    if ([string]::IsNullOrWhiteSpace($accountId)) { $accountId = [Environment]::GetEnvironmentVariable("CLOUDFLARE_ACCOUNT_ID", "Machine") }
    $accountSet = -not [string]::IsNullOrWhiteSpace($accountId)
    $authHint = "Detected auth env: token={0}, account={1}" -f ($(if($tokenSet){"set"}else{"unset"}), $(if($accountSet){$accountId}else{"unset"}))
    $text = $out -join " "

    # Order matters: a missing project also surfaces wrangler's "non-interactive context"
    # message as a secondary error, which reads like an auth failure but is not one.
    if ($text -match "Project not found" -or $text -match "does not match any of your existing projects" -or $text -match "8000007") {
      $hint = @(
        "Pages project '$PagesProject' does not exist in this account (404 Project not found).",
        $authHint,
        "This is NOT an auth failure - the token authenticated fine but the project is missing.",
        "Fix: check the exact project name (hyphens/case) in the Cloudflare dashboard,",
        "or create it once: Workers & Pages > Create > Pages > Direct Upload.",
        "Then rerun with the matching -PagesProject value."
      ) -join [Environment]::NewLine
      throw "wrangler pages deploy failed (exit=$exit). $hint"
    }

    if ($text -match "Authentication error" -or $text -match "Unable to authenticate" -or $text -match "\b(401|403)\b" -or $text -match "code: ?10000") {
      $hint = @(
        "Cloudflare rejected the credentials (auth error).",
        $authHint,
        "Check that CLOUDFLARE_API_TOKEN is valid, unexpired, and has the",
        "'Cloudflare Pages: Edit' permission for account $accountId.",
        "Verify with: wrangler whoami"
      ) -join [Environment]::NewLine
      throw "wrangler pages deploy failed (exit=$exit). $hint"
    }

    if ($text -match "non-interactive context") {
      $hint = @(
        "wrangler pages deploy requires non-interactive credentials.",
        $authHint,
        "Set CLOUDFLARE_API_TOKEN and CLOUDFLARE_ACCOUNT_ID in environment, then rerun.",
        "Example:",
        "  `$env:CLOUDFLARE_API_TOKEN = '***'",
        "  `$env:CLOUDFLARE_ACCOUNT_ID = '***'",
        "  .\\asktodo-registry-full-sync.ps1 -UploadMethod pages -PagesProject asktodo-hub -ContinueOnRebuildFailure"
      ) -join [Environment]::NewLine
      throw "wrangler pages deploy failed (exit=$exit). $hint"
    }

    throw "wrangler pages deploy failed (exit=$exit). $authHint"
  }
  Write-Status ("Pages deploy finished: https://{0}.pages.dev" -f $PagesProject)
}

function Invoke-HttpUpload {
  if (-not $UploadUrl) { throw "UploadUrl missing. Set -UploadUrl or ASKTODO_DASHBOARD_UPLOAD_URL." }
  try {
    $uploadUri = New-Object System.Uri($UploadUrl.TrimEnd('/'))
    if (-not $uploadUri.IsAbsoluteUri -or -not $uploadUri.Scheme.StartsWith('http')) {
      throw "UploadUrl must be http/https."
    }
  } catch {
    throw "Invalid UploadUrl: $UploadUrl"
  }

  $files = Get-FileListForUpload
  if (-not $files.Count) {
    Write-Status "No files to upload."
    return
  }
  if ($files.Count -gt $MaxUploadFiles) {
    throw "Too many upload targets: $($files.Count) files (max $MaxUploadFiles)."
  }

  $curl = Get-Command curl.exe -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $curl) { throw "curl.exe not found. Use system curl or install." }

  $authHeader = @()
  if ($UploadAuth) {
    $authValue = $UploadAuth
    if (($UploadAuthHeader -ieq 'Authorization') -and ($UploadAuth -notmatch '^\w+\s+')) {
      $authValue = "Bearer $UploadAuth"
    }
    $authHeader = @("-H", ("{0}: {1}" -f $UploadAuthHeader, $authValue))
  }

  $methodList = if ($UploadHttpMethod -eq "AUTO") { @("PUT", "POST") } else { @($UploadHttpMethod) }
  Write-Status ("3/3 Worker API upload start: {0}, files={1}, method={2}" -f $UploadUrl, $files.Count, $UploadHttpMethod)
  $uploaded = 0
  $uploadErrors = @()
  foreach ($file in $files) {
    $relative = $file.FullName.Substring($StagingRoot.Length).TrimStart('\','/')
    $target = Resolve-UploadUrl $relative
    $successfulMethod = $null
    $fileErrors = @()
    foreach ($method in $methodList) {
      $prevErrorAction = $ErrorActionPreference
      $ErrorActionPreference = "Continue"
      try {
        $out = & $curl.Source -sS --fail-with-body -X $method --upload-file $file.FullName @authHeader --header "Content-Type: application/octet-stream" $target 2>&1
        $exitCode = $LASTEXITCODE
      } catch {
        $out = @([string]$_.Exception.Message)
        $exitCode = 1
      } finally {
        $ErrorActionPreference = $prevErrorAction
      }

      if ($exitCode -eq 0) {
        $successfulMethod = $method
        Write-Status ("upload ok: {0} via {1}" -f $relative, $method)
        break
      }
      $msg = ("method={0} exit={1} out={2}" -f $method, $exitCode, (($out -join " ") -replace "`r?`n", " "))
      $fileErrors += $msg
      Write-Status ("upload retry needed: {0}" -f $msg)
      if ($UploadHttpMethod -ne "AUTO") { break }
    }
    if (-not $successfulMethod) {
      $uploadErrors += ("[{0}] {1}" -f $relative, ($fileErrors -join " | "))
      continue
    }
    $uploaded++
  }
  if ($uploadErrors.Count) {
    throw ("Upload failed for {0} files.`n{1}" -f $uploadErrors.Count, ($uploadErrors -join "`n"))
  }
  Write-Status ("HTTP upload complete: {0}" -f $uploaded)
}

function Show-UploadHint {
  Write-Status "Upload is disabled because no upload target is configured."
  Write-Status "Set one of:"
  Write-Status "1) -UploadMethod pages -PagesProject <project> or ASKTODO_DASHBOARD_PAGES_PROJECT"
  Write-Status "2) -UploadMethod http -UploadUrl <https://...> or ASKTODO_DASHBOARD_UPLOAD_URL"
  Write-Status ("Current staging: {0}" -f $StagingRoot)
}

function Resolve-UploadMethod {
  if ($effectiveUploadMethod -ne "auto") { return $effectiveUploadMethod }
  $hasPages = $PagesProject -and (
    (Get-Command wrangler -ErrorAction SilentlyContinue) -or
    (Get-Command npx -ErrorAction SilentlyContinue)
  )
  if ($hasPages) { return "pages" }
  if ($UploadUrl) { return "http" }
  return "none"
}

Write-Status "ASK/Todo sync pipeline start"
if (-not $SkipRebuild) { Invoke-RebuildTasks } else { Write-Status "1/3 skip rebuild." }
if (-not $NoDashboard) { Invoke-BuildDashboard } else { Write-Status "2/3 skip dashboard build." }
New-Staging

if ($NoUpload) {
  Write-Status ("3/3 skip upload (-NoUpload). staging={0}" -f $StagingRoot)
} else {
  $method = Resolve-UploadMethod
  switch ($method) {
    "pages" { Invoke-PagesDeploy }
    "http"  { Invoke-HttpUpload }
    default { Show-UploadHint }
  }
}

if ($OpenDashboard -and (Test-Path -LiteralPath $dashboardIndex)) {
  Start-Process -FilePath $dashboardIndex | Out-Null
}

if (-not $KeepStaging -and (Test-Path -LiteralPath $StagingRoot)) {
  Remove-Item -LiteralPath $StagingRoot -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Status ("done. dashboard: {0}" -f $dashboardIndex)
