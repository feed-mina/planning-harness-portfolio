<!-- ask-todo-recognition:start -->
## ASK/Todo 대화 기록 관례

`ASK/` 폴더가 있는 저장소에서 사용자가 "오늘 대화/작업을 ASK에 기록/정리해줘", "ASK 로그 남겨줘" 등을 요청하면 아래 규칙으로 기록한다. (원조: `kiba_2026`)

### 스코프 / 안전
- **등록 폴더만**: `ASK/` 폴더가 없는 저장소에서는 자동 기록하지 않는다(명시 요청 시 생성만).
- **보류 플래그**: `.ask_paused` 또는 `scripts/.claude_ask_paused` 가 있으면 자동 기록을 건너뛴다.
- **git 근거만**: 오늘(Asia/Seoul) `git log --since=midnight`, `git status`, 작업트리 변경, 보이는 아티팩트에 근거해서만. **추측·창작 금지.**
- **보존(append)**: 기존 한국어 내용을 훼손하지 말고 새 블록만 덧붙인다.
- 기록 전 `git fetch` 로 원격 드리프트를 확인한다.

### ASK 포맷 — `ASK/YYYY-MM-DD_ai.md` (없으면 헤더로 시작)

```markdown
# YYYY-MM-DD Claude/Codex 질문·응답 로그

> 작성 규칙: 질문마다 한 블록. 질문 한 줄 요약 + 응답 2~3줄 요약.
> 도구 구분: `Claude`, `Codex`, 또는 `Claude+Codex`.

---
```

질문마다 한 블록씩 append (여러 블록은 `---` 로 구분):

```markdown
## 주제 요약
**도구:** Codex
**질문:** 한 줄 요약
**응답 요약:**
- 핵심 응답 1
- 핵심 응답 2
- (필요하면) 다음 할 일
```

### 도구 구분
- Codex 단독이면 `Codex`, Claude 단독이면 `Claude`, 이어서 함께면 `Claude+Codex`.

### Todo — `Todo/YYYY-MM-DD_<주제>.md`
- 구체적 후속 작업이 있을 때만 생성. 체크리스트는 `- [ ]` / `- [x]`.

### 커밋 / 발행
- 수동 요청 시 파일 편집 후 `git add ASK Todo && git commit` 까지. push/미러/발행은 프로젝트 스케줄 스크립트가 처리한다.
- git 은 읽기(log/status/diff)만으로 오늘 작업을 파악하고, 임의의 명령·푸시는 하지 않는다.
<!-- ask-todo-recognition:end -->
