﻿<#
  asktodo-dashboard.ps1  (중앙 허브 통합 뷰 — Phase 4)

  registry.json 에 등록된 프로젝트의 ASK/Todo 를 mirror/ 로 복사하고,
  dashboard/index.html 에 프로젝트별 상태와 최근 ASK 항목을 모으고,
  dashboard/search.html 에 프로젝트별 ASK 전문 검색을 만든다.
#>
[CmdletBinding()]
param(
  [switch]$NoMirror,
  [switch]$Open,
  [switch]$Preview,
  [string[]]$ExcludePatterns = @("*.secret*", "*secret*", "*credentials*", "*credential*", "*.env", "*.key", "*.pem", "*password*"),
  [bool]$MaskSensitive = $true
)

$ErrorActionPreference = "Stop"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

function Resolve-HubRoot {
  if ($PSScriptRoot) { return (Resolve-Path -LiteralPath $PSScriptRoot).Path }
  if ($PSCommandPath) { return (Split-Path -Parent (Resolve-Path -LiteralPath $PSCommandPath).Path) }
  return (Get-Location).Path
}

$hubRoot = Resolve-HubRoot
$registryPath = Join-Path $hubRoot "registry.json"
$mirrorRoot = Join-Path $hubRoot "mirror"
$dashboardRoot = Join-Path $hubRoot "dashboard"
$indexPath = Join-Path $dashboardRoot "index.html"
$searchPath = Join-Path $dashboardRoot "search.html"

function Read-Registry {
  if (Test-Path -LiteralPath $registryPath) {
    try {
      $obj = Get-Content -Raw -Encoding UTF8 -LiteralPath $registryPath | ConvertFrom-Json
      $projects = @()
      if ($obj.projects) { $projects = @($obj.projects) }
      return [pscustomobject]@{ version = 1; projects = $projects }
    } catch {
      throw "registry.json 파싱 실패: $($_.Exception.Message)"
    }
  }
  return [pscustomobject]@{ version = 1; projects = @() }
}

function Convert-ToSafeName([string]$name) {
  $safe = $name -replace '[^\p{L}\p{Nd}\._-]+', '_'
  $safe = $safe.Trim("._-")
  if ([string]::IsNullOrWhiteSpace($safe)) { return "project" }
  return $safe
}

function Escape-Html([string]$value) {
  if ($null -eq $value) { return "" }
  return [System.Net.WebUtility]::HtmlEncode($value)
}

function Convert-ToEmbeddedJson($value) {
  if ($null -eq $value) { return "[]" }
  $json = ConvertTo-Json -InputObject @($value) -Depth 8 -Compress
  return $json.Replace("&", "\u0026").Replace("<", "\u003c").Replace(">", "\u003e")
}

function Convert-ToRelativeHref([string]$path) {
  if ([string]::IsNullOrWhiteSpace($path)) { return "" }
  return (($path -replace '\\', '/') -replace ' ', '%20')
}

function Assert-InsideDirectory([string]$child, [string]$parent) {
  $parentFull = [System.IO.Path]::GetFullPath($parent).TrimEnd('\') + '\'
  $childFull = [System.IO.Path]::GetFullPath($child).TrimEnd('\') + '\'
  if (-not $childFull.StartsWith($parentFull, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw "안전하지 않은 mirror 경로입니다: $child"
  }
}

function Get-TaskState([string]$taskName) {
  if ([string]::IsNullOrWhiteSpace($taskName)) { return "(없음)" }
  if (-not (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue)) { return "(확인 불가)" }
  try {
    $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if ($task) { return $task.State.ToString() }
  } catch {}
  return "(태스크 없음)"
}

function Get-TaskLastResult([string]$taskName) {
  if ([string]::IsNullOrWhiteSpace($taskName)) { return "" }
  if (-not (Get-Command Get-ScheduledTaskInfo -ErrorAction SilentlyContinue)) { return "" }
  try {
    $info = Get-ScheduledTaskInfo -TaskName $taskName -ErrorAction SilentlyContinue
    if ($info) { return "exit={0}" -f $info.LastTaskResult }
  } catch {}
  return ""
}

function Get-ProjectLogId([pscustomobject]$project) {
  if ($project.id) { return [string]$project.id }
  if ($project.path) {
    return ([Convert]::ToBase64String(([Text.Encoding]::UTF8.GetBytes(([string]$project.path).ToLowerInvariant())))).TrimEnd('=').Replace('+','-').Replace('/','_')
  }
  return [string]$project.name
}

function Read-ProjectStatus([pscustomobject]$project) {
  $logId = Get-ProjectLogId $project
  $statusPath = Join-Path $hubRoot ("logs\{0}.status.json" -f $logId)
  if (-not (Test-Path -LiteralPath $statusPath)) { return $null }
  try { return Get-Content -Raw -Encoding UTF8 -LiteralPath $statusPath | ConvertFrom-Json } catch { return $null }
}

function Is-ExcludedFile([string]$path) {
  if (-not $ExcludePatterns -or -not $ExcludePatterns.Count) { return $false }
  $name = [System.IO.Path]::GetFileName($path)
  foreach ($pattern in $ExcludePatterns) {
    if ($name -like $pattern -or $path -like $pattern) { return $true }
  }
  return $false
}

function Redact-SensitiveText([string]$text) {
  if (-not $MaskSensitive -or [string]::IsNullOrWhiteSpace($text)) { return $text }
  $result = $text
  $result = $result -replace "(?i)(api[_-]?key|access[_-]?token|secret|token|password|pwd|auth|bearer)\s*[:=]\s*([A-Za-z0-9\-_\.=\/\+]{8,})", '$1=[REDACTED]'
  $result = $result -replace '(?i)\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b', '[EMAIL_REDACTED]'
  $result = $result -replace '(?im)\b\d{2,4}-\d{3,4}-\d{4}\b', '[PHONE_REDACTED]'
  return $result
}

function Test-ProjectPaused([string]$path) {
  if (-not (Test-Path -LiteralPath $path)) { return $false }
  return (Test-Path -LiteralPath (Join-Path $path ".ask_paused")) -or
         (Test-Path -LiteralPath (Join-Path $path "scripts\.claude_ask_paused"))
}

function Get-MarkdownFiles([string]$dir) {
  if (-not (Test-Path -LiteralPath $dir)) { return @() }
  return @(Get-ChildItem -LiteralPath $dir -Filter "*.md" -File -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -ne "README.md" -and -not (Is-ExcludedFile $_.FullName) } |
    Sort-Object LastWriteTime -Descending)
}

function Get-TodoStats([string]$dir) {
  $files = Get-MarkdownFiles $dir
  $open = 0
  $done = 0
  foreach ($file in $files) {
    $text = Get-Content -Raw -Encoding UTF8 -LiteralPath $file.FullName -ErrorAction SilentlyContinue
    if ($text) {
      $open += ([regex]::Matches($text, '(?m)^\s*-\s*\[\s\]')).Count
      $done += ([regex]::Matches($text, '(?m)^\s*-\s*\[[xX]\]')).Count
    }
  }
  return [pscustomobject]@{ Files = $files.Count; Open = $open; Done = $done }
}

function Get-AskTopics([string]$path, [int]$limit = 3) {
  if (-not (Test-Path -LiteralPath $path)) { return @() }
  $text = Get-Content -Raw -Encoding UTF8 -LiteralPath $path -ErrorAction SilentlyContinue
  if (-not $text) { return @() }
  return @([regex]::Matches($text, '(?m)^##\s+(.+)$') |
    Select-Object -First $limit |
    ForEach-Object { $_.Groups[1].Value.Trim() })
}

function Convert-MarkdownToSearchText([string]$text) {
  if ([string]::IsNullOrWhiteSpace($text)) { return "" }
  $plain = $text -replace '(?s)```.*?```', ' '
  $plain = $plain -replace '(?m)^\s{0,3}#{1,6}\s*', ''
  $plain = $plain -replace '\[([^\]]+)\]\([^)]+\)', '$1'
  $plain = $plain -replace '[*_`>#|~-]+', ' '
  $plain = $plain -replace '\s+', ' '
  $plain = Redact-SensitiveText $plain
  return $plain.Trim()
}

function Sync-ProjectMirror($project, [string]$safeName) {
  if ($NoMirror) { return }
  if (-not (Test-Path -LiteralPath $project.path)) { return }
  if (-not (Test-Path -LiteralPath $mirrorRoot)) {
    New-Item -ItemType Directory -Force -Path $mirrorRoot | Out-Null
  }
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  $target = Join-Path $mirrorRoot $safeName
  Assert-InsideDirectory $target $mirrorRoot
  if (Test-Path -LiteralPath $target) {
    Remove-Item -LiteralPath $target -Recurse -Force
  }
  New-Item -ItemType Directory -Force -Path $target | Out-Null
  foreach ($dirName in @("ASK", "Todo")) {
    $source = Join-Path $project.path $dirName
    if (Test-Path -LiteralPath $source) {
      $targetDir = Join-Path $target $dirName
      New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
      $files = @(Get-ChildItem -LiteralPath $source -Filter "*.md" -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -ne "README.md" -and -not (Is-ExcludedFile $_.FullName) })
      foreach ($file in @($files)) {
        if ($MaskSensitive) {
          $content = Get-Content -Raw -Encoding UTF8 -LiteralPath $file.FullName -ErrorAction SilentlyContinue
          $content = Redact-SensitiveText $content
          $dest = Join-Path $targetDir $file.Name
          [System.IO.File]::WriteAllText($dest, $content, $utf8)
        } else {
          Copy-Item -LiteralPath $file.FullName -Destination $targetDir -Force
        }
      }
    }
  }
}

function New-ProjectSummary($project, [string]$safeName) {
  $path = [string]$project.path
  $exists = Test-Path -LiteralPath $path
  $timeText = if ($project.times) {
    (($project.times | ForEach-Object { [string]$_ }) -join ", ")
  } elseif ($project.time) {
    [string]$project.time
  } else {
    ""
  }
  $askDir = Join-Path $path "ASK"
  $todoDir = Join-Path $path "Todo"
  $askFiles = Get-MarkdownFiles $askDir
  $todoStats = Get-TodoStats $todoDir
  $latestAsk = $null
  if ($askFiles.Count -gt 0) { $latestAsk = $askFiles[0] }
  $latestAskHref = ""
  if ($latestAsk) {
    $latestAskHref = Convert-ToRelativeHref ("../mirror/{0}/ASK/{1}" -f $safeName, $latestAsk.Name)
  }
  $status = Read-ProjectStatus $project
  $lastRun = if ($status -and $status.lastRunAt) { (Get-Date $status.lastRunAt).ToString("yyyy-MM-dd HH:mm:ss") } else { "" }
  $captureStatus = if ($status -and $status.capture -and $status.capture.status) { [string]$status.capture.status } else { "" }
  $publishStatus = if ($status -and $status.publish -and $status.publish.status) { [string]$status.publish.status } else { "" }
  $exitCode = if ($status -and $status.exitCode -ne $null) { [string]$status.exitCode } else { "" }
  return [pscustomobject]@{
    Name = [string]$project.name
    Path = $path
    SafeName = $safeName
    Tool = [string]$project.tool
    Time = $timeText
    TaskName = [string]$project.taskName
    TaskState = Get-TaskState ([string]$project.taskName)
    TaskLastResult = Get-TaskLastResult ([string]$project.taskName)
    Exists = $exists
    Paused = Test-ProjectPaused $path
    AskCount = $askFiles.Count
    TodoCount = $todoStats.Files
    TodoOpen = $todoStats.Open
    TodoDone = $todoStats.Done
    LatestAsk = if ($latestAsk) { $latestAsk.Name } else { "" }
    LatestAskTime = if ($latestAsk) { $latestAsk.LastWriteTime } else { $null }
    LatestAskHref = $latestAskHref
    LastRunAt = $lastRun
    CaptureStatus = $captureStatus
    PublishStatus = $publishStatus
    ExitCode = $exitCode
  }
}

function New-RecentAskItems($summaries) {
  $items = @()
  foreach ($summary in $summaries) {
    $mirrorAskDir = Join-Path $mirrorRoot (Join-Path $summary.SafeName "ASK")
    $files = Get-MarkdownFiles $mirrorAskDir
    foreach ($file in $files) {
      $items += [pscustomobject]@{
        Project = $summary.Name
        File = $file.Name
        Time = $file.LastWriteTime
        Href = Convert-ToRelativeHref ("../mirror/{0}/ASK/{1}" -f $summary.SafeName, $file.Name)
        Topics = @(Get-AskTopics $file.FullName 3)
      }
    }
  }
  return @($items | Sort-Object Time -Descending | Select-Object -First 20)
}

function New-SearchIndex($summaries) {
  $docs = @()
  foreach ($summary in $summaries) {
    $askDir = Join-Path $mirrorRoot (Join-Path $summary.SafeName "ASK")
    $hrefRoot = "../mirror/{0}/ASK" -f $summary.SafeName

    if (-not (Test-Path -LiteralPath $askDir)) {
      $sourceAskDir = Join-Path $summary.Path "ASK"
      if (-not (Test-Path -LiteralPath $sourceAskDir)) { continue }
      $askDir = $sourceAskDir
      $hrefRoot = ""
    }

    foreach ($file in (Get-MarkdownFiles $askDir)) {
      $raw = Get-Content -Raw -Encoding UTF8 -LiteralPath $file.FullName -ErrorAction SilentlyContinue
      if ([string]::IsNullOrWhiteSpace($raw)) { continue }
      $topics = @(Get-AskTopics $file.FullName 8)
      $plain = Convert-MarkdownToSearchText $raw
      $excerpt = $plain
      if ($excerpt.Length -gt 260) { $excerpt = $excerpt.Substring(0, 260) + "..." }
      $href = ""
      if ($hrefRoot) {
        $href = Convert-ToRelativeHref ("{0}/{1}" -f $hrefRoot, $file.Name)
      }
      $docs += [pscustomobject]@{
        project = $summary.Name
        file = $file.Name
        date = $file.LastWriteTime.ToString("yyyy-MM-dd HH:mm")
        href = $href
        topics = $topics
        excerpt = $excerpt
        text = $plain
      }
    }
  }
  return @($docs | Sort-Object date -Descending)
}

function Write-DashboardHtml($summaries, $recentItems) {
  if (-not (Test-Path -LiteralPath $dashboardRoot)) {
    New-Item -ItemType Directory -Force -Path $dashboardRoot | Out-Null
  }
  $generatedAt = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
  $totalProjects = @($summaries).Count
  $pausedProjects = @($summaries | Where-Object { $_.Paused }).Count
  $openTodos = (@($summaries | ForEach-Object { $_.TodoOpen }) | Measure-Object -Sum).Sum
  if ($null -eq $openTodos) { $openTodos = 0 }
  $askFiles = (@($summaries | ForEach-Object { $_.AskCount }) | Measure-Object -Sum).Sum
  if ($null -eq $askFiles) { $askFiles = 0 }

  $projectRows = foreach ($s in $summaries) {
    $projectCell = '<strong>{0}</strong><div class="path">{1}</div>' -f (Escape-Html $s.Name), (Escape-Html $s.Path)
    $status = if (-not $s.Exists) { "missing" } elseif ($s.Paused) { "paused" } else { "active" }
    $latest = if ($s.LatestAskHref) {
      '<a href="{0}">{1}</a>' -f (Escape-Html $s.LatestAskHref), (Escape-Html $s.LatestAsk)
    } else {
      '<span class="muted">없음</span>'
    }
    '<tr><td>{0}</td><td><span class="badge {1}">{1}</span></td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td><td>{6}</td><td>{7}</td><td>{8}</td><td>{9}</td><td>{10}</td><td>{11}</td></tr>' -f
      $projectCell,
      (Escape-Html $status),
      (Escape-Html $s.Tool),
      (Escape-Html $s.Time),
      (Escape-Html ("{0} {1}" -f $s.TaskState, $s.TaskLastResult)),
      $s.AskCount,
      ("{0} / {1}" -f $s.TodoOpen, $s.TodoDone),
      $latest,
      (Escape-Html $s.LastRunAt),
      (Escape-Html $s.CaptureStatus),
      (Escape-Html $s.PublishStatus),
      (Escape-Html $s.ExitCode)
  }

  $recentRows = foreach ($item in $recentItems) {
    $topics = if ($item.Topics.Count -gt 0) {
      ($item.Topics | ForEach-Object { '<span class="topic">{0}</span>' -f (Escape-Html $_) }) -join ""
    } else {
      '<span class="muted">주제 없음</span>'
    }
    '<li><a href="{0}">{1}</a><span>{2}</span><div>{3}</div></li>' -f
      (Escape-Html $item.Href),
      (Escape-Html ("{0} / {1}" -f $item.Project, $item.File)),
      (Escape-Html ($item.Time.ToString("yyyy-MM-dd HH:mm"))),
      $topics
  }
  if (-not $recentRows) { $recentRows = '<li><span class="muted">아직 미러링된 ASK 파일이 없습니다.</span></li>' }
  if (-not $projectRows) { $projectRows = '<tr><td colspan="12" class="muted">등록된 프로젝트가 없습니다.</td></tr>' }

  $html = @"
<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ASK/Todo Hub Dashboard</title>
  <style>
    :root { color-scheme: light; --ink:#1f2937; --muted:#6b7280; --line:#d7dde5; --bg:#f6f7f9; --panel:#ffffff; --active:#0f766e; --paused:#9a3412; --missing:#b91c1c; --accent:#2563eb; }
    * { box-sizing: border-box; }
    body { margin:0; font-family: "Segoe UI", Arial, sans-serif; background:var(--bg); color:var(--ink); }
    header { background:var(--panel); border-bottom:1px solid var(--line); padding:22px 28px 18px; }
    h1 { margin:0 0 6px; font-size:24px; letter-spacing:0; }
    main { padding:22px 28px 36px; }
    .meta { color:var(--muted); font-size:13px; }
    .stats { display:grid; grid-template-columns:repeat(4, minmax(140px, 1fr)); gap:12px; margin:18px 0 22px; }
    .stat { background:var(--panel); border:1px solid var(--line); border-radius:8px; padding:14px 16px; }
    .stat strong { display:block; font-size:24px; margin-bottom:4px; }
    section { margin-top:20px; }
    h2 { font-size:17px; margin:0 0 10px; }
    table { width:100%; border-collapse:collapse; background:var(--panel); border:1px solid var(--line); border-radius:8px; overflow:hidden; }
    th, td { padding:11px 12px; border-bottom:1px solid var(--line); text-align:left; vertical-align:top; font-size:14px; }
    th { background:#eef2f7; color:#374151; font-weight:600; }
    tr:last-child td { border-bottom:none; }
    a { color:var(--accent); text-decoration:none; }
    a:hover { text-decoration:underline; }
    .path { color:var(--muted); font-size:12px; margin-top:3px; }
    .muted { color:var(--muted); }
    .badge { display:inline-block; min-width:62px; padding:3px 8px; border-radius:999px; color:white; font-size:12px; text-align:center; }
    .active { background:var(--active); }
    .paused { background:var(--paused); }
    .missing { background:var(--missing); }
    .recent { list-style:none; padding:0; margin:0; display:grid; gap:10px; }
    .recent li { background:var(--panel); border:1px solid var(--line); border-radius:8px; padding:12px 14px; }
    .recent li > span { float:right; color:var(--muted); font-size:12px; }
    .topic { display:inline-block; margin:8px 6px 0 0; padding:3px 7px; background:#eef2f7; border:1px solid var(--line); border-radius:6px; font-size:12px; color:#374151; }
    @media (max-width: 780px) {
      main, header { padding-left:16px; padding-right:16px; }
      .stats { grid-template-columns:repeat(2, minmax(120px, 1fr)); }
      table { display:block; overflow-x:auto; }
      .recent li > span { float:none; display:block; margin-top:4px; }
    }
  </style>
</head>
<body>
  <header>
    <h1>ASK/Todo Hub Dashboard</h1>
    <div class="meta">생성: $(Escape-Html $generatedAt) · 허브: $(Escape-Html $hubRoot) · <a href="search.html">ASK 전문 검색</a></div>
  </header>
  <main>
    <div class="stats">
      <div class="stat"><strong>$totalProjects</strong><span>등록 프로젝트</span></div>
      <div class="stat"><strong>$askFiles</strong><span>ASK 파일</span></div>
      <div class="stat"><strong>$openTodos</strong><span>열린 Todo</span></div>
      <div class="stat"><strong>$pausedProjects</strong><span>보류 프로젝트</span></div>
    </div>

    <section>
      <h2>프로젝트</h2>
      <table>
        <thead>
          <tr><th>프로젝트</th><th>상태</th><th>도구</th><th>시간</th><th>태스크</th><th>ASK</th><th>Todo 열림/완료</th><th>최근 ASK</th><th>마지막 실행</th><th>AI</th><th>발행</th><th>종료코드</th></tr>
        </thead>
        <tbody>
          $($projectRows -join "`n          ")
        </tbody>
      </table>
    </section>

    <section>
      <h2>최근 ASK</h2>
      <ul class="recent">
        $($recentRows -join "`n        ")
      </ul>
    </section>
  </main>
</body>
</html>
"@
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($indexPath, $html, $utf8)
}

function Write-SearchHtml($summaries, $searchDocs) {
  if (-not (Test-Path -LiteralPath $dashboardRoot)) {
    New-Item -ItemType Directory -Force -Path $dashboardRoot | Out-Null
  }
  $generatedAt = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
  $privacyHint = "민감정보 보호: 민감 패턴은 마스킹되며, 패턴 일치 파일은 제외됩니다."
  $projectOptions = foreach ($s in $summaries) {
    '<option value="{0}">{0}</option>' -f (Escape-Html $s.Name)
  }
  $searchJson = Convert-ToEmbeddedJson $searchDocs
  $html = @'
<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>ASK Full Text Search</title>
  <style>
    :root { color-scheme: light; --ink:#1f2937; --muted:#6b7280; --line:#d7dde5; --bg:#f6f7f9; --panel:#ffffff; --accent:#2563eb; --mark:#fff2a8; }
    * { box-sizing: border-box; }
    body { margin:0; font-family:"Segoe UI", Arial, sans-serif; background:var(--bg); color:var(--ink); }
    header { background:var(--panel); border-bottom:1px solid var(--line); padding:22px 28px 18px; }
    h1 { margin:0 0 6px; font-size:24px; letter-spacing:0; }
    main { padding:22px 28px 36px; }
    a { color:var(--accent); text-decoration:none; }
    a:hover { text-decoration:underline; }
    .meta, .hint { color:var(--muted); font-size:13px; }
    .controls { display:grid; grid-template-columns:minmax(220px, 1fr) 220px 110px; gap:10px; margin:18px 0 12px; }
    input, select, button { height:38px; border:1px solid var(--line); border-radius:6px; padding:0 10px; font:inherit; background:white; color:var(--ink); }
    button { background:var(--accent); border-color:var(--accent); color:white; cursor:pointer; }
    .summary { margin:10px 0 18px; color:var(--muted); }
    .results { list-style:none; margin:0; padding:0; display:grid; gap:10px; }
    .results li { background:var(--panel); border:1px solid var(--line); border-radius:8px; padding:14px 16px; }
    .title { display:flex; justify-content:space-between; gap:12px; align-items:flex-start; margin-bottom:8px; }
    .title strong { font-size:15px; }
    .date { color:var(--muted); font-size:12px; white-space:nowrap; }
    .snippet { line-height:1.55; color:#374151; }
    mark { background:var(--mark); padding:0 2px; border-radius:3px; }
    .topic { display:inline-block; margin:8px 6px 0 0; padding:3px 7px; background:#eef2f7; border:1px solid var(--line); border-radius:6px; font-size:12px; color:#374151; }
    .empty { background:var(--panel); border:1px solid var(--line); border-radius:8px; padding:18px; color:var(--muted); }
    @media (max-width: 760px) {
      main, header { padding-left:16px; padding-right:16px; }
      .controls { grid-template-columns:1fr; }
      .title { display:block; }
      .date { display:block; margin-top:4px; }
    }
  </style>
</head>
<body>
  <header>
    <h1>ASK 전문 검색</h1>
    <div class="meta">생성: __GENERATED_AT__ · <a href="index.html">대시보드로 돌아가기</a></div>
  </header>
  <main>
    <div class="controls">
      <input id="query" type="search" placeholder="검색어를 입력하세요" autocomplete="off" autofocus>
      <select id="project">
        <option value="">전체 프로젝트</option>
        __PROJECT_OPTIONS__
      </select>
      <button id="clear" type="button">초기화</button>
    </div>
    <div class="hint">공백으로 여러 단어를 입력하면 모두 포함된 ASK 파일을 찾습니다. 프로젝트를 선택하면 해당 프로젝트 안에서만 검색합니다. __PRIVACY_HINT__</div>
    <div id="summary" class="summary"></div>
    <ul id="results" class="results"></ul>
  </main>
  <script>
    const DOCS = __SEARCH_JSON__;
    const queryEl = document.getElementById("query");
    const projectEl = document.getElementById("project");
    const clearEl = document.getElementById("clear");
    const summaryEl = document.getElementById("summary");
    const resultsEl = document.getElementById("results");

    function escapeHtml(value) {
      return String(value || "").replace(/[&<>"']/g, ch => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
      }[ch]));
    }

    function terms() {
      return queryEl.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
    }

    function matches(doc, selectedProject, words) {
      if (selectedProject && doc.project !== selectedProject) return false;
      if (!words.length) return true;
      const haystack = [doc.project, doc.file, (doc.topics || []).join(" "), doc.text].join(" ").toLowerCase();
      return words.every(word => haystack.includes(word));
    }

    function makeSnippet(doc, words) {
      const text = doc.text || doc.excerpt || "";
      if (!text) return "";
      const lower = text.toLowerCase();
      let index = -1;
      for (const word of words) {
        index = lower.indexOf(word);
        if (index >= 0) break;
      }
      if (index < 0) index = 0;
      const start = Math.max(0, index - 90);
      const end = Math.min(text.length, index + 220);
      let snippet = text.slice(start, end);
      if (start > 0) snippet = "..." + snippet;
      if (end < text.length) snippet += "...";
      let html = escapeHtml(snippet);
      for (const word of words) {
        if (!word) continue;
        const escaped = word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
        html = html.replace(new RegExp("(" + escaped + ")", "gi"), "<mark>$1</mark>");
      }
      return html;
    }

    function render() {
      const selectedProject = projectEl.value;
      const words = terms();
      const results = DOCS.filter(doc => matches(doc, selectedProject, words));
      summaryEl.textContent = `${results.length}개 결과 / ${DOCS.length}개 ASK 파일`;
      if (!results.length) {
        resultsEl.innerHTML = '<li class="empty">검색 결과가 없습니다.</li>';
        return;
      }
      resultsEl.innerHTML = results.slice(0, 200).map(doc => {
        const title = `${doc.project} / ${doc.file}`;
        const titleHtml = doc.href
          ? `<a href="${escapeHtml(doc.href)}"><strong>${escapeHtml(title)}</strong></a>`
          : `<strong>${escapeHtml(title)}</strong>`;
        const topics = (doc.topics || []).map(topic => `<span class="topic">${escapeHtml(topic)}</span>`).join("");
        return `<li>
          <div class="title">${titleHtml}<span class="date">${escapeHtml(doc.date)}</span></div>
          <div class="snippet">${makeSnippet(doc, words)}</div>
          <div>${topics}</div>
        </li>`;
      }).join("");
    }

    queryEl.addEventListener("input", render);
    projectEl.addEventListener("change", render);
    clearEl.addEventListener("click", () => {
      queryEl.value = "";
      projectEl.value = "";
      queryEl.focus();
      render();
    });
    render();
  </script>
</body>
</html>
'@
  $html = $html.Replace("__GENERATED_AT__", (Escape-Html $generatedAt))
  $html = $html.Replace("__PROJECT_OPTIONS__", ($projectOptions -join "`n        "))
  $html = $html.Replace("__PRIVACY_HINT__", (Escape-Html $privacyHint))
  $html = $html.Replace("__SEARCH_JSON__", $searchJson)
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($searchPath, $html, $utf8)
}

$reg = Read-Registry
$used = @{}
$summaries = @()

foreach ($project in @($reg.projects)) {
  $safeName = Convert-ToSafeName ([string]$project.name)
  if ($used.ContainsKey($safeName)) {
    $used[$safeName] += 1
    $safeName = "{0}-{1}" -f $safeName, $used[$safeName]
  } else {
    $used[$safeName] = 1
  }
  if (-not $Preview) { Sync-ProjectMirror $project $safeName }
  $summaries += New-ProjectSummary $project $safeName
}

if ($Preview) {
  "{0} project(s) would be included." -f @($summaries).Count | Write-Host
  foreach ($summary in $summaries) {
    "{0}: ASK={1}, TodoOpen={2}, Paused={3}, Exists={4}" -f $summary.Name, $summary.AskCount, $summary.TodoOpen, $summary.Paused, $summary.Exists | Write-Host
  }
  return
}

$recentItems = New-RecentAskItems $summaries
$searchDocs = New-SearchIndex $summaries
Write-DashboardHtml $summaries $recentItems
Write-SearchHtml $summaries $searchDocs
Write-Host "[DONE] dashboard: $indexPath"
Write-Host "[DONE] search: $searchPath"

if ($Open) {
  Start-Process -FilePath $indexPath | Out-Null
}
