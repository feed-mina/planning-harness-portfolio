﻿[CmdletBinding()]
param([switch]$RemoveUserData, [switch]$SkipShellIntegration)

$ErrorActionPreference = "Stop"
$targetRoot = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$manifestPath = Join-Path $targetRoot "version-manifest.json"
$runtimeFiles = @()
if (Test-Path -LiteralPath $manifestPath) {
  $runtimeFiles = @((Get-Content -Raw -Encoding UTF8 -LiteralPath $manifestPath | ConvertFrom-Json).files)
}

if (-not $SkipShellIntegration) {
  $shortcutPath = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\ASKTodoHub.lnk"
  if (Test-Path -LiteralPath $shortcutPath) { Remove-Item -LiteralPath $shortcutPath -Force }
  $uninstallKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\ASKTodoHub"
  if (Test-Path -LiteralPath $uninstallKey) { Remove-Item -LiteralPath $uninstallKey -Recurse -Force }
}

foreach ($relativePath in $runtimeFiles) {
  if ($relativePath -in @("registry.json", "logs")) { continue }
  $path = Join-Path $targetRoot $relativePath
  if (Test-Path -LiteralPath $path -PathType Leaf) { Remove-Item -LiteralPath $path -Force }
}
if (Test-Path -LiteralPath $manifestPath) { Remove-Item -LiteralPath $manifestPath -Force }

if ($RemoveUserData) {
  $resolved = [IO.Path]::GetFullPath($targetRoot)
  $allowedRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA "Programs\ASKTodoHub"))
  if (-not $resolved.Equals($allowedRoot, [StringComparison]::OrdinalIgnoreCase)) { throw "Refusing user-data removal outside the installer target." }
  Remove-Item -LiteralPath (Join-Path $targetRoot "registry.json") -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath (Join-Path $targetRoot "logs") -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "[DONE] ASK/Todo Hub runtime removed. User registry/logs preserved=$(-not $RemoveUserData)"
