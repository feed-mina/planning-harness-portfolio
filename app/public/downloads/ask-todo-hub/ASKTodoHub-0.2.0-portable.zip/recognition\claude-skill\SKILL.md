---
name: ask-todo
description: Record the current Claude/Codex conversation into a project's ASK/Todo log, or set up ASK/Todo in a project. Use when the user asks to log the day's work or conversation — e.g. "오늘 대화 ASK에 기록", "오늘 작업 ASK/Todo 정리", "ASK 로그 남겨줘", "record today's conversation", "ASK/Todo 만들어줘". Only auto-logs in projects that already have an ASK/ folder.
---

# ASK/Todo 대화 기록 규칙

프로젝트의 `ASK/`·`Todo/` 폴더에 그날의 Claude/Codex 질문·응답과 구체적 후속 할 일을 누적하는 관례다. (원조: `kiba_2026`)

## 언제 동작하나
- 사용자가 "오늘 대화를 ASK에 기록/정리", "ASK 로그 남겨줘", "오늘 작업 ASK/Todo에 남겨줘" 등으로 요청할 때.
- 작업 중인 저장소에 `ASK/` 폴더가 **있을 때**(= 등록된 프로젝트).
- `ASK/` 가 **없는데** 사용자가 "여기에도 ASK/Todo 붙여줘"라고 하면 아래 포맷으로 `ASK/`·`Todo/` 를 새로 만든다(README 헤더 포함).

## 스코프 / 안전 규칙
- **등록 폴더만**: `ASK/` 폴더가 없는 저장소에서는 자동 기록하지 않는다. (명시 요청 시 생성만)
- **보류 플래그**: `.ask_paused` 또는 `scripts/.claude_ask_paused` 파일이 있으면 자동 기록을 건너뛴다.
- **git 근거만**: 오늘(Asia/Seoul) `git log --since=midnight --oneline`, `git status`, 작업트리 변경, 눈에 보이는 아티팩트에 근거해서만 기록한다. **추측·창작 금지.**
- **보존(append)**: 기존 한국어 내용을 절대 훼손하지 말고, 새 블록만 덧붙인다.
- **드리프트 주의**: 로컬이 origin보다 뒤처져 있을 수 있으니, 기록 전 `git fetch` 로 원격 상태를 확인한다.

## ASK 포맷 — `ASK/YYYY-MM-DD_ai.md`

파일이 없으면 이 헤더로 시작한다:

```markdown
# YYYY-MM-DD Claude/Codex 질문·응답 로그

> 작성 규칙: 질문마다 한 블록. 질문 한 줄 요약 + 응답 2~3줄 요약.
> 도구 구분: `Claude`, `Codex`, 또는 `Claude+Codex`.

---
```

질문마다 한 블록씩 누적(append)한다:

```markdown
## 주제 요약
**도구:** Claude
**질문:** 한 줄 요약
**응답 요약:**
- 핵심 응답 1
- 핵심 응답 2
- (필요하면) 다음 할 일
```

여러 블록은 `---` 로 구분한다.

## 도구 구분
- 이번 대화가 Claude 단독이면 `**도구:** Claude`
- Codex 단독이면 `**도구:** Codex`
- 두 도구가 같은 주제를 이어서 작업했으면 `**도구:** Claude+Codex`

## Todo — `Todo/YYYY-MM-DD_<주제>.md`
- **구체적 후속 작업이 있을 때만** 만든다. 단순 기록이면 Todo 파일을 만들지 않는다.
- 체크리스트는 `- [ ]` / `- [x]` 형식(보드가 진행도를 파싱함).

## 커밋 / 발행
- 수동 요청 시: 파일 편집 후 `git add ASK Todo && git commit` 까지 한다. push/미러/발행은 프로젝트에 스케줄 스크립트가 있으면 그쪽이 처리한다.
- 무인 스케줄 실행은 별도 스크립트(`asktodo-capture.ps1` 등)가 담당한다. 이 스킬은 대화 중 수동 기록용이다.
- 자동으로 임의의 명령·푸시를 하지 말고, git 은 읽기(log/status/diff)만으로 오늘 작업을 파악한다.
