﻿<#
  ASK/Todo Hub multi-project discovery, validation, clone, and registration.

  This script uses the system git/credential helper. It never accepts or stores
  access tokens and never overwrites an existing clone destination.
#>
[CmdletBinding()]
param(
  [ValidateSet("scan", "validate", "clone", "add-many")][string]$Action = "validate",
  [string]$ParentPath,
  [string[]]$Paths,
  [string]$RepoUrl,
  [string]$DestinationRoot,
  [ValidateRange(0, 6)][int]$MaxDepth = 2,
  [ValidateSet("claude", "codex", "both")][string]$Tool = "claude",
  [string[]]$Times = @("17:30"),
  [switch]$Temporary,
  [switch]$AsJson
)

$ErrorActionPreference = "Stop"
$hubRoot = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$registerScript = Join-Path $hubRoot "asktodo-register.ps1"

function Resolve-Git {
  $command = Get-Command git.exe -ErrorAction SilentlyContinue
  if (-not $command) { $command = Get-Command git -ErrorAction SilentlyContinue }
  if (-not $command) { throw "Git is not installed or not available on PATH." }
  return $command.Source
}

function Invoke-GitCapture([string[]]$Arguments) {
  $git = Resolve-Git
  $previousErrorActionPreference = $ErrorActionPreference
  try {
    $ErrorActionPreference = "Continue"
    return @(& $git @Arguments 2>$null)
  } finally {
    $ErrorActionPreference = $previousErrorActionPreference
  }
}

function Normalize-LocalPath([string]$Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) { return $null }
  try { return [IO.Path]::GetFullPath($Path.Trim()).TrimEnd('\') } catch { return $null }
}

function Get-RepositoryInfo([string]$Path) {
  $candidate = Normalize-LocalPath $Path
  if (-not $candidate -or -not (Test-Path -LiteralPath $candidate -PathType Container)) {
    return [pscustomobject]@{ ok = $false; input = $Path; reason = "path_not_found"; path = $candidate }
  }
  $bare = (Invoke-GitCapture @("-C", $candidate, "rev-parse", "--is-bare-repository") | Select-Object -First 1)
  if ([string]$bare -notin @("true", "false")) { return [pscustomobject]@{ ok = $false; input = $Path; reason = "not_git_repository"; path = $candidate } }
  if ([string]$bare -eq "true") { return [pscustomobject]@{ ok = $false; input = $Path; reason = "bare_repository"; path = $candidate } }
  $topLevel = (Invoke-GitCapture @("-C", $candidate, "rev-parse", "--show-toplevel") | Select-Object -First 1)
  if ([string]::IsNullOrWhiteSpace($topLevel)) {
    return [pscustomobject]@{ ok = $false; input = $Path; reason = "not_work_tree"; path = $candidate }
  }
  $canonical = Normalize-LocalPath $topLevel
  $remote = (Invoke-GitCapture @("-C", $canonical, "remote", "get-url", "origin") | Select-Object -First 1)
  return [pscustomobject]@{
    ok = $true
    input = $Path
    reason = "ok"
    path = $canonical
    name = Split-Path -Leaf $canonical
    repoUrl = if (-not [string]::IsNullOrWhiteSpace($remote)) { [string]$remote } else { "" }
    worktree = Test-Path -LiteralPath (Join-Path $canonical ".git") -PathType Leaf
  }
}

function Get-RepositoryCandidates([string]$Root, [int]$Depth) {
  $rootPath = Normalize-LocalPath $Root
  if (-not $rootPath -or -not (Test-Path -LiteralPath $rootPath -PathType Container)) { throw "Parent path not found: $Root" }
  $queue = New-Object System.Collections.Queue
  $queue.Enqueue([pscustomobject]@{ path = $rootPath; depth = 0 })
  $results = @()
  while ($queue.Count -gt 0) {
    $item = $queue.Dequeue()
    $info = Get-RepositoryInfo $item.path
    if ($info.ok -and $info.path -eq (Normalize-LocalPath $item.path)) {
      $results += $info
      continue
    }
    if ($item.depth -ge $Depth) { continue }
    foreach ($child in @(Get-ChildItem -LiteralPath $item.path -Directory -Force -ErrorAction SilentlyContinue)) {
      if ($child.Name -in @(".git", "node_modules", ".gradle", "dist", "build")) { continue }
      $queue.Enqueue([pscustomobject]@{ path = $child.FullName; depth = ($item.depth + 1) })
    }
  }
  return @($results | Sort-Object path -Unique)
}

function Normalize-GitHubUrl([string]$Url) {
  if ([string]::IsNullOrWhiteSpace($Url)) { throw "Repository URL is required." }
  $value = $Url.Trim()
  $match = [regex]::Match($value, '^(?:https://github\.com/|git@github\.com:)([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+?)(?:\.git)?$')
  if (-not $match.Success) { throw "Unsupported GitHub URL. Use https://github.com/owner/repo or git@github.com:owner/repo.git" }
  return [pscustomobject]@{
    owner = $match.Groups[1].Value
    name = $match.Groups[2].Value
    cloneUrl = if ($value.StartsWith("git@")) { "git@github.com:$($match.Groups[1].Value)/$($match.Groups[2].Value).git" } else { "https://github.com/$($match.Groups[1].Value)/$($match.Groups[2].Value).git" }
  }
}

function Clone-Repository([string]$Url, [string]$Root) {
  $normalized = Normalize-GitHubUrl $Url
  $destinationRootPath = Normalize-LocalPath $Root
  if (-not $destinationRootPath -or -not (Test-Path -LiteralPath $destinationRootPath -PathType Container)) { throw "Clone destination root not found: $Root" }
  $destination = Join-Path $destinationRootPath $normalized.name
  if (Test-Path -LiteralPath $destination) { throw "Clone destination already exists: $destination" }
  $git = Resolve-Git
  $previousErrorActionPreference = $ErrorActionPreference
  try {
    $ErrorActionPreference = "Continue"
    & $git clone -- $normalized.cloneUrl $destination
  } finally {
    $ErrorActionPreference = $previousErrorActionPreference
  }
  if (-not (Test-Path -LiteralPath (Join-Path $destination ".git"))) { throw "git clone failed. Check network, repository access, and system Git credentials." }
  if ($Temporary) {
    [pscustomobject]@{ owner = "ASKTodoHub"; createdAt = [DateTime]::UtcNow.ToString("o") } |
      ConvertTo-Json | Set-Content -LiteralPath (Join-Path $destination ".asktodo-owned-temp.json") -Encoding UTF8
  }
  return Get-RepositoryInfo $destination
}

function Register-Many([string[]]$InputPaths) {
  if (-not (Test-Path -LiteralPath $registerScript -PathType Leaf)) { throw "Registration script missing: $registerScript" }
  $seen = @{}
  $results = @()
  foreach ($inputPath in @($InputPaths)) {
    $info = Get-RepositoryInfo $inputPath
    if (-not $info.ok) { $results += $info; continue }
    $key = $info.path.ToLowerInvariant()
    if ($seen.ContainsKey($key)) {
      $results += [pscustomobject]@{ ok = $false; input = $inputPath; path = $info.path; reason = "duplicate_path" }
      continue
    }
    $seen[$key] = $true
    try {
      & $registerScript -Action add -RepoRoot $info.path -Tool $Tool -Times $Times -InstallMode $(if ($Temporary) { "temporary" } else { "personal" }) | Out-Null
      $results += [pscustomobject]@{ ok = $true; input = $inputPath; path = $info.path; reason = "registered"; repoUrl = $info.repoUrl; worktree = $info.worktree }
    } catch {
      $results += [pscustomobject]@{ ok = $false; input = $inputPath; path = $info.path; reason = "registration_failed"; error = $_.Exception.Message }
    }
  }
  return $results
}

$result = switch ($Action) {
  "scan" { Get-RepositoryCandidates $ParentPath $MaxDepth }
  "validate" { @($Paths | ForEach-Object { Get-RepositoryInfo $_ }) }
  "clone" { Clone-Repository $RepoUrl $DestinationRoot }
  "add-many" { Register-Many $Paths }
}

if ($AsJson) { $result | ConvertTo-Json -Depth 6 } else { $result }
