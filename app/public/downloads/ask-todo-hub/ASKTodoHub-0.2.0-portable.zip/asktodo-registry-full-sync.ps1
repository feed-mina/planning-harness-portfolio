﻿<#
  asktodo-registry-full-sync.ps1 (batch flow)

  1) Rebuild tasks from registry.json using asktodo-register.ps1.
  2) Build dashboard and sync to Worker/static.
  3) Save execution logs.
#>
[CmdletBinding()]
param(
  [ValidateSet("auto", "pages", "http", "none")][string]$UploadMethod = "auto",
  [ValidateSet("AUTO", "PUT", "POST")][string]$UploadHttpMethod = "AUTO",
  [string]$PagesProject,
  [string]$PagesBranch,
  [string]$UploadUrl,
  [string]$UploadAuth,
  [string]$UploadAuthHeader = "Authorization",
  [string]$UploadPrefix = "ask-todo-hub",
  [string]$RegistryPath,
  [switch]$SkipSanitizeInteractive,
  [switch]$SkipRebuild,
  [switch]$NoUpload,
  [switch]$KeepStaging,
  [switch]$OpenDashboard,
  [int]$MaxUploadFiles = 2000,
  [switch]$ContinueOnRebuildFailure
)

$ErrorActionPreference = "Stop"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

function Resolve-HubRoot {
  if ($PSScriptRoot) { return (Resolve-Path -LiteralPath $PSScriptRoot).Path }
  if ($PSCommandPath) { return (Split-Path -Parent (Resolve-Path -LiteralPath $PSCommandPath).Path) }
  return (Get-Location).Path
}

$hubRoot = Resolve-HubRoot
$registerScript = Join-Path $hubRoot "asktodo-register.ps1"
$dashboardSyncScript = Join-Path $hubRoot "asktodo-dashboard-sync.ps1"
$registryPath = if ($RegistryPath) { $RegistryPath } else { Join-Path $hubRoot "registry.json" }
$logDir = Join-Path $hubRoot "logs"
if (-not (Test-Path -LiteralPath $logDir)) { New-Item -ItemType Directory -Force -Path $logDir | Out-Null }
$logFile = Join-Path $logDir ("asktodo-registry-full-sync-{0}.log" -f (Get-Date -Format "yyyyMMdd-HHmmss"))

if (-not $PagesProject) { $PagesProject = [Environment]::GetEnvironmentVariable("ASKTODO_DASHBOARD_PAGES_PROJECT") }
if (-not $UploadUrl) { $UploadUrl = [Environment]::GetEnvironmentVariable("ASKTODO_DASHBOARD_UPLOAD_URL") }
if (-not $UploadAuth) { $UploadAuth = [Environment]::GetEnvironmentVariable("ASKTODO_DASHBOARD_UPLOAD_TOKEN") }

function Write-Log {
  param([string]$Message)
  $line = "[{0}] {1}" -f (Get-Date -Format "HH:mm:ss"), $Message
  Write-Host $line
  $line | Add-Content -LiteralPath $logFile -Encoding UTF8
}

function Invoke-SubProcess {
  param(
    [string]$Name,
    [string]$File,
    [string[]]$Arguments
  )

  Write-Log ("{0} start: {1} {2}" -f $Name, (Split-Path -Leaf $File), ($Arguments -join " "))
  $previous = $ErrorActionPreference
  try {
    $ErrorActionPreference = "Continue"
    $out = @(& powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $File @Arguments 2>&1)
  } finally {
    $ErrorActionPreference = $previous
  }
  $exit = $LASTEXITCODE
  foreach ($line in @($out)) { if ($line) { Write-Log ("  " + [string]$line) } }
  Write-Log ("{0} exit={1}" -f $Name, $exit)
  return [pscustomobject]@{ ExitCode = $exit; Output = @($out) }
}

function Get-RegistryCount {
  if (-not (Test-Path -LiteralPath $registryPath)) { return 0 }
  try {
    $raw = Get-Content -Raw -LiteralPath $registryPath -Encoding UTF8 | ConvertFrom-Json
    return @($raw.projects).Count
  } catch {
    throw "registry.json parse failed: $($_.Exception.Message)"
  }
}

Write-Log "ASK/Todo full sync start"
Write-Log ("Hub: $hubRoot")
Write-Log ("UploadMethod: $UploadMethod")
Write-Log ("Registry: $registryPath")
if (Test-Path -LiteralPath $registerScript) {
  Write-Log ("register script: $registerScript")
} else {
  throw "register script not found: $registerScript"
}
if (Test-Path -LiteralPath $dashboardSyncScript) {
  Write-Log ("dashboard sync script: $dashboardSyncScript")
} else {
  throw "dashboard sync script not found: $dashboardSyncScript"
}

$count = Get-RegistryCount
Write-Log ("registry projects: $count")

$summary = [ordered]@{
  rebuild = [ordered]@{ called = -not $SkipRebuild; exitCode = 0; failed = 0; rebuilt = 0; skipped = 0; processed = 0 }
  dashboard = [ordered]@{ exitCode = 0 }
}

if (-not $SkipSanitizeInteractive) {
  $sanitizeResult = Invoke-SubProcess -Name "sanitize-interactive" -File $registerScript -Arguments @("-Action", "sanitize-tasks")
  if ($sanitizeResult.ExitCode -ne 0) {
    Write-Log "sanitize-interactive failed, continue"
  }
}

if (-not $SkipRebuild) {
  $rebuildResult = Invoke-SubProcess -Name "rebuild-tasks" -File $registerScript -Arguments @("-Action", "rebuild-tasks")
  $summary.rebuild.exitCode = $rebuildResult.ExitCode

  $done = $rebuildResult.Output | Where-Object { $_ -match "\[DONE\]\s+processed=" } | Select-Object -First 1
  if ($done -match "processed=(\d+),\s*rebuilt=(\d+),\s*skipped=(\d+),\s*failed=(\d+)") {
    $summary.rebuild.processed = [int]$matches[1]
    $summary.rebuild.rebuilt = [int]$matches[2]
    $summary.rebuild.skipped = [int]$matches[3]
    $summary.rebuild.failed = [int]$matches[4]
  } else {
    Write-Log "rebuild result summary not parsed"
  }

  if ($summary.rebuild.failed -gt 0 -and -not $ContinueOnRebuildFailure) {
    throw ("rebuild failed (failed={0}). Use -ContinueOnRebuildFailure to keep going." -f $summary.rebuild.failed)
  }
}

$dashArgs = @(
  "-UploadMethod", $UploadMethod,
  "-UploadHttpMethod", $UploadHttpMethod,
  "-MaxUploadFiles", $MaxUploadFiles
)
if ($PagesProject) { $dashArgs += @("-PagesProject", $PagesProject) }
# Left unset by default so asktodo-dashboard-sync.ps1 owns the production-branch default.
if ($PagesBranch) { $dashArgs += @("-PagesBranch", $PagesBranch) }
if ($UploadUrl) { $dashArgs += @("-UploadUrl", $UploadUrl) }
if ($UploadAuth) { $dashArgs += @("-UploadAuth", $UploadAuth) }
if ($UploadAuthHeader) { $dashArgs += @("-UploadAuthHeader", $UploadAuthHeader) }
if ($UploadPrefix) { $dashArgs += @("-UploadPrefix", $UploadPrefix) }
if ($RegistryPath) { $dashArgs += @("-RegistryPath", $registryPath) }
if ($NoUpload) { $dashArgs += "-NoUpload" }
if ($KeepStaging) { $dashArgs += "-KeepStaging" }
if ($OpenDashboard) { $dashArgs += "-OpenDashboard" }

# Task rebuilding is owned by this wrapper, so the dashboard subprocess must
# never repeat it, including after ContinueOnRebuildFailure.
$dashArgs += "-SkipRebuild"

$dashResult = Invoke-SubProcess -Name "dashboard-sync" -File $dashboardSyncScript -Arguments $dashArgs
$summary.dashboard.exitCode = $dashResult.ExitCode

Write-Log ("summary rebuilt={0}, skipped={1}, failed={2}, exitCode={3}" -f $summary.rebuild.rebuilt, $summary.rebuild.skipped, $summary.rebuild.failed, $summary.rebuild.exitCode)
Write-Log ("summary dashboardExit={0}" -f $summary.dashboard.exitCode)
Write-Log ("log saved: $logFile")

if ($summary.rebuild.exitCode -ne 0 -or $summary.dashboard.exitCode -ne 0 -or $summary.rebuild.failed -gt 0) {
  Write-Log "full sync completed with warnings/errors"
  if ($summary.rebuild.failed -gt 0 -and -not $ContinueOnRebuildFailure) {
    exit 2
  }
  exit 1
}

Write-Log "full sync completed successfully"
exit 0
