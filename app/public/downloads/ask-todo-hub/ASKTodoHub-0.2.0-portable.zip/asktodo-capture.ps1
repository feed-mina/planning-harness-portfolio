﻿<#
  asktodo-capture.ps1  (ASK/Todo 캡처기 - 통합 보안 강화)

  임의의 git 저장소에서 오늘(Asia/Seoul) Claude/Codex 작업 근거를 읽기 전용으로 수집하고
  ASK/Todo 기록 파일만 갱신한다.

  기본 동작:
  - 기록 전용: publish는 기본 비활성
  - -Publish: 명시적으로만 push/pull/commit 수행
  - 실행 실패 시 0이 아닌 종료 코드 반환
  - 실행 상태를 logs/<repo-id>.status.json 에 기록
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$RepoRoot,
  [ValidateSet("claude", "codex", "both")][string]$Tool = "claude",
  [switch]$NoPublish,
  [switch]$Publish,
  [switch]$NoCapture
)

$ErrorActionPreference = "Stop"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
$OutputEncoding = New-Object System.Text.UTF8Encoding($false)

function Resolve-HubRoot {
  if ($PSScriptRoot) { return (Resolve-Path -LiteralPath $PSScriptRoot).Path }
  if ($PSCommandPath) { return (Split-Path -Parent (Resolve-Path -LiteralPath $PSCommandPath).Path) }
  return (Get-Location).Path
}

$RepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path
$hubRoot  = Resolve-HubRoot
$repoName = Split-Path -Leaf $RepoRoot
$logDir   = Join-Path $hubRoot "logs"
$runId    = (Get-Date -Format "yyyyMMddHHmmss") + "-" + [Guid]::NewGuid().ToString("N")
$utf8 = New-Object System.Text.UTF8Encoding($false)
$LogRetentionDays = 30

function Get-ProjectId([string]$Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) { return $repoName }
  return ([Convert]::ToBase64String(([Text.Encoding]::UTF8.GetBytes($Path.ToLowerInvariant())))).TrimEnd('=').Replace('+','-').Replace('/','_')
}

$projectId = Get-ProjectId $RepoRoot
$logFile   = Join-Path $logDir ("{0}.log" -f $projectId)
$statusFile = Join-Path $logDir ("{0}.status.json" -f $projectId)
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Force -Path $logDir | Out-Null }

function Mask-Text([string]$value) {
  $text = $value
  $text = $text -replace "sk-ant-[A-Za-z0-9_\-]+", "sk-ant-***"
  $text = $text -replace "(?i)(api[_-]?key|token)\s*[:=]\s*[^ \r\n]{8,}", '$1=***'
  $text = $text -replace "https?://[^\s/$.?#].[^\s]*", "<URL_MASKED>"
  return $text
}

function Write-Log([string]$msg) {
  $line = "[{0}] {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), (Mask-Text $msg)
  Add-Content -Path $logFile -Value $line -Encoding UTF8
}

function Rotate-LogArtifacts {
  if (-not (Test-Path -LiteralPath $logDir)) { return }
  $cutoff = (Get-Date).AddDays(-$LogRetentionDays)
  $items = @(
    @(Get-ChildItem -LiteralPath $logDir -File -Filter *.log -ErrorAction SilentlyContinue)
    @(Get-ChildItem -LiteralPath $logDir -File -Filter *.json -ErrorAction SilentlyContinue)
  )
  foreach ($item in @($items | Where-Object { $_ })) {
    if ($item.LastWriteTime -lt $cutoff) {
      Remove-Item -LiteralPath $item.FullName -Force -ErrorAction SilentlyContinue
    }
  }
}

function Get-StatusPath {
  return $statusFile
}

function Write-Status([pscustomobject]$State) {
  try { [System.IO.File]::WriteAllText((Get-StatusPath), (ConvertTo-Json -InputObject $State -Depth 12), $utf8) } catch {}
}

function Ensure-AskTodo {
  $askDir  = Join-Path $RepoRoot "ASK"
  $todoDir = Join-Path $RepoRoot "Todo"
  foreach ($pair in @(@{ Dir = $askDir; Tpl = "ASK-README.md" }, @{ Dir = $todoDir; Tpl = "Todo-README.md" })) {
    if (-not (Test-Path $pair.Dir)) {
      New-Item -ItemType Directory -Force -Path $pair.Dir | Out-Null
      $tpl = Join-Path $hubRoot ("templates\" + $pair.Tpl)
      if (Test-Path $tpl) { Copy-Item $tpl (Join-Path $pair.Dir "README.md") -Force }
    }
  }
}

function Test-Paused {
  return (Test-Path (Join-Path $RepoRoot ".ask_paused")) -or
         (Test-Path (Join-Path $RepoRoot "scripts\.claude_ask_paused"))
}

function Get-GitStatusSnapshot {
  Push-Location $RepoRoot
  $previousErrorActionPreference = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  try {
    $lines = @(& git -c core.excludesFile= status --short --untracked-files=all 2>$null)
    $code = $LASTEXITCODE
    if ($code -ne 0) { throw "git status failed (exit $code)" }
    return @($lines | ForEach-Object {
      $line = $_.ToString()
      $path = if ($line.Length -gt 3) { $line.Substring(3).Trim() } else { "" }
      if ($path -and $path -match "->") { $path = ($path -split "->")[-1].Trim() }
      if ($path -like '"*"') { $path = $path.Trim('"') }
      $path.Replace("/", "\")
    })
  } finally {
    $ErrorActionPreference = $previousErrorActionPreference
    Pop-Location
  }
}

function Is-AllowedPath([string]$Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
  $normalized = $Path.Replace("/", "\")
  return $normalized -like "ASK\*" -or $normalized -like "Todo\*" -or $normalized -like ".\ASK\*" -or $normalized -like ".\Todo\*"
}

function Get-UnauthorizedChanges([string[]]$Before, [string[]]$After) {
  $beforeSet = @{}
  foreach ($item in @($Before)) {
    if ($item) { $beforeSet[($item.ToLowerInvariant())] = $true }
  }
  $bad = @()
  foreach ($item in @($After)) {
    if (-not $item) { continue }
    $lower = $item.ToLowerInvariant()
    if ($beforeSet.ContainsKey($lower)) { continue }
    if (-not (Is-AllowedPath $item)) { $bad += $item }
  }
  return @($bad)
}

function Import-AnthropicApiKey {
  if (-not [string]::IsNullOrWhiteSpace($env:ANTHROPIC_API_KEY)) { return }
  $keyFile = Join-Path $hubRoot ".anthropic_api_key.xml"
  if (-not (Test-Path $keyFile)) { Write-Log "Auth: no local key file (headless may be blocked)"; return }
  try {
    $secure = Get-Content $keyFile | ConvertTo-SecureString
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { $env:ANTHROPIC_API_KEY = ([Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)).Trim() }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
  } catch { Write-Log ("Auth: decrypt failed: " + $_.Exception.Message) }
}

function Resolve-ClaudeExe {
  $bases = @(
    (Join-Path $env:APPDATA "Claude\claude-code"),
    (Join-Path $env:LOCALAPPDATA "Packages\Claude_pzs8sxrjxfjjc\LocalCache\Roaming\Claude\claude-code")
  )
  foreach ($base in $bases) {
    if (-not (Test-Path $base)) { continue }
    $latest = Get-ChildItem $base -Directory -ErrorAction SilentlyContinue |
      Sort-Object { try { [version]$_.Name } catch { [version]"0.0.0" } } | Select-Object -Last 1
    if ($latest) {
      $exe = Join-Path $latest.FullName "claude.exe"
      if (Test-Path $exe) { return $exe }
    }
  }
  $command = Get-Command claude -ErrorAction SilentlyContinue
  if ($command) { return $command.Source }
  return $null
}

function Get-CapturePrompt([string]$toolName, [string]$today) {
  return @"
오늘(${today}) 현재 저장소($RepoRoot)에서 $toolName 작업 기록 근거만 읽고 근거 기반으로 정리해줘.

규칙:
- git log --since=midnight --oneline, git status, git diff에서 확인되는 근거만 사용
- 추측하거나 창작하지 않기
- 응답은 JSON 객체 하나만 반환
- JSON 스키마:
{
  "has_updates": true,
  "question": "작업 한 줄 요약(질문 또는 수행한 작업)",
  "topic": "오늘 작업 주제 한 줄",
  "summary": ["핵심 응답 요약1", "핵심 응답 요약2", "핵심 응답 요약3"],
  "todos": ["후속 TODO 항목", "후속 TODO 항목"]
}
- 새로 기록할 근거가 없으면 has_updates는 false이고 summary/todos는 빈 배열
- summary는 1~3개 문자열
- JSON 바깥 텍스트 출력 금지
"@
}

function Parse-Payload([string]$text) {
  if (-not $text) { return $null }
  $matches = [regex]::Matches($text, "(?s)\{.*?\}")
  for ($i = $matches.Count - 1; $i -ge 0; $i--) {
    $candidate = $matches[$i].Value
    try {
      $obj = $candidate | ConvertFrom-Json -ErrorAction Stop
      if ($obj -and $obj.PSObject.Properties["has_updates"]) { return $obj }
    } catch {}
  }
  return $null
}

function Normalize-Payload([string]$Tool, [pscustomobject]$Payload) {
  if (-not $Payload) {
    return [pscustomobject]@{
      tool = $Tool
      hasUpdates = $false
      question = "AI 응답 해석 실패"
      topic = "응답 해석 실패"
      summary = @("AI 응답을 JSON으로 해석하지 못했습니다.")
      todos = @()
    }
  }

  $hasUpdates = $false
  try { $hasUpdates = [bool]$Payload.has_updates } catch {}
  $question = if ($Payload.question) { [string]$Payload.question } else { "" }
  $topic = if ($Payload.topic) { [string]$Payload.topic } else { "" }
  $summary = @()
  if ($Payload.summary) {
    $summary = @($Payload.summary | ForEach-Object { if ($_) { [string]$_ } })
  } elseif ($Payload.response_summary) {
    $summary = @($Payload.response_summary | ForEach-Object { if ($_) { [string]$_ } })
  }
  if (-not $summary.Count) { $summary = @("기록 가능한 근거가 없습니다.") }
  $todos = @()
  if ($Payload.todos) { $todos = @($Payload.todos | ForEach-Object { if ($_) { [string]$_ } }) }
  return [pscustomobject]@{
    tool = $Tool
    hasUpdates = $hasUpdates
    question = $question
    topic = $topic
    summary = $summary
    todos = $todos
  }
}

function Write-AiRecord($Results) {
  $today = Get-Date -Format "yyyy-MM-dd"
  $askDir = Join-Path $RepoRoot "ASK"
  $todoDir = Join-Path $RepoRoot "Todo"
  $askFile = Join-Path $askDir ("{0}_ai.md" -f $today)
  $updated = @{}
  $todos = @()

  $hasUpdate = $false
  foreach ($item in @($Results)) {
    if ($item -and $item.hasUpdates) { $hasUpdate = $true }
    if ($item.todos) {
      $todos += @($item.todos | Where-Object { $_ -and ([string]$_).Trim() })
    }
    if ($item.topic) { $updated[[string]$item.topic] = $true }
  }

  if (-not $hasUpdate) {
    return [pscustomobject]@{ written = $false; file = ""; todoFiles = @() }
  }

  if (-not (Test-Path $askDir)) { New-Item -ItemType Directory -Force -Path $askDir | Out-Null }
  if (-not (Test-Path -LiteralPath $todoDir)) { New-Item -ItemType Directory -Force -Path $todoDir | Out-Null }

  if (-not (Test-Path -LiteralPath $askFile)) {
    $header = @"
# $today Claude/Codex 질문·응답 로그

> 작성 규칙: 질문마다 한 블록. 질문 한 줄 요약 + 응답 2~3줄 요약.

"@
    [System.IO.File]::WriteAllText($askFile, $header, $utf8)
  }

  $topics = @($updated.Keys)
  if (-not $topics.Count) { $topics = @("AI 기록") }
  $blockTool = if (@($Results).Count -gt 1) { "Claude+Codex" } else { [string]$Results[0].tool }
  $questionLine = if (@($Results).Count -gt 1) {
    "Claude + Codex 통합 요약"
  } else {
    [string]$Results[0].question
  }

  $summaryLines = @()
  foreach ($entry in @($Results)) {
    $prefix = if (@($Results).Count -gt 1) { "[{0}] " -f $entry.tool } else { "" }
    foreach ($line in @($entry.summary)) {
      if ($line) {
        $summaryLines += ("{0}{1}" -f $prefix, $line)
      }
    }
  }
  if ($summaryLines.Count -gt 3) { $summaryLines = $summaryLines[0..2] }

  $summaryBlock = @($summaryLines | ForEach-Object { " - $_" }) -join "`r`n"
  if (-not $summaryBlock) { $summaryBlock = "- 기록 내용 없음" }

  $block = @"
## 주제 요약
**도구:** $blockTool
**질문:** $questionLine
**응답 요약:**
$summaryBlock

"@

  Add-Content -Path $askFile -Value $block -Encoding UTF8

  $writtenTodoFiles = @()
  $uniqTodos = @($todos | Select-Object -Unique)
  if ($uniqTodos.Count -gt 0) {
    $safeTopic = [regex]::Replace($topics[0], "[^A-Za-z0-9가-힣_-]+", "_")
    if ([string]::IsNullOrWhiteSpace($safeTopic)) { $safeTopic = "followup" }
    $todoFile = Join-Path $todoDir ("{0}_{1}.md" -f $today, $safeTopic)
    if (-not (Test-Path -LiteralPath $todoFile)) {
      $todoHeader = @"
## Todo
"@
      [System.IO.File]::WriteAllText($todoFile, $todoHeader, $utf8)
    }
    foreach ($todoItem in $uniqTodos) {
      Add-Content -Path $todoFile -Value ("- [ ] {0}" -f $todoItem) -Encoding UTF8
    }
    $writtenTodoFiles += $todoFile
  }

  return [pscustomobject]@{ written = $true; file = $askFile; todoFiles = $writtenTodoFiles; topic = $topics[0] }
}

function Invoke-ClaudeCapture {
  Import-AnthropicApiKey
  $exe = Resolve-ClaudeExe
  if (-not $exe) { return [pscustomobject]@{ tool = "Claude"; status = "skipped"; exitCode = -1; hasUpdates = $false; payload = $null; reason = "claude 실행 파일 없음"; todoFiles = @() } }
  Write-Log ("Claude: using " + $exe)

  $prompt = Get-CapturePrompt "Claude" (Get-Date -Format "yyyy-MM-dd")
  $allowed = @("Read","Glob","Grep","Bash(git log:*)","Bash(git status:*)","Bash(git diff:*)","Bash(git show:*)")
  $askDir = Join-Path $RepoRoot "ASK"
  $todoDir = Join-Path $RepoRoot "Todo"
  $claudeArgs = @('-p', $prompt, '--permission-mode', 'default', '--allowedTools') + $allowed +
    @('--add-dir', $askDir, '--add-dir', $todoDir, '--output-format', 'text')
  $output = @()
  $creditBlocked = $false

  Push-Location $RepoRoot
  try {
    $prev = $ErrorActionPreference; $ErrorActionPreference = "Continue"
    try {
      foreach ($line in (& $exe @claudeArgs 2>&1)) {
        if ($line) {
          $text = $line.ToString()
          if ($text -match 'Credit balance is too low') { $creditBlocked = $true }
          $output += $text
          Write-Log ("claude: " + $text)
        }
      }
    } finally { $ErrorActionPreference = $prev }
  } finally { Pop-Location }

  $code = $LASTEXITCODE
  $payload = Parse-Payload (($output -join "`n"))
  if ($code -eq 0 -and -not $creditBlocked -and $payload) {
    $normalized = Normalize-Payload "Claude" $payload
    return [pscustomobject]@{
      tool = "Claude"; status = "success"; exitCode = $code; hasUpdates = $normalized.hasUpdates;
      payload = $normalized; reason = ""; todoFiles = @()
    }
  }

  $reason = "Claude 종료 코드 $code"
  if ($creditBlocked) { $reason = "Credit balance is too low" }
  if (-not $payload) { $reason += " / JSON 해석 실패" }
  $normalizedPayload = $null
  if ($payload) { $normalizedPayload = Normalize-Payload "Claude" $payload }
  return [pscustomobject]@{
    tool = "Claude"; status = "failed"; exitCode = $code; hasUpdates = $false;
    payload = $normalizedPayload; reason = $reason; todoFiles = @()
  }
}

function Invoke-CodexCapture {
  $codex = Get-Command codex -ErrorAction SilentlyContinue
  if (-not $codex) {
    return [pscustomobject]@{ tool = "Codex"; status = "skipped"; exitCode = -1; hasUpdates = $false; payload = $null; reason = "codex CLI 없음"; todoFiles = @() }
  }
  Write-Log ("Codex: using " + $codex.Source)
  $prompt = Get-CapturePrompt "Codex" (Get-Date -Format "yyyy-MM-dd")
  $output = @()

  Push-Location $RepoRoot
  try {
    $prev = $ErrorActionPreference; $ErrorActionPreference = "Continue"
    try {
      foreach ($line in (& $codex.Source exec --sandbox read-only $prompt 2>&1)) {
        if ($line) {
          $text = $line.ToString()
          $output += $text
          Write-Log ("codex: " + $text)
        }
      }
    } finally { $ErrorActionPreference = $prev }
  } finally { Pop-Location }

  $code = $LASTEXITCODE
  $payload = Parse-Payload (($output -join "`n"))
  if ($code -eq 0 -and $payload) {
    $normalized = Normalize-Payload "Codex" $payload
    return [pscustomobject]@{
      tool = "Codex"; status = "success"; exitCode = $code; hasUpdates = $normalized.hasUpdates;
      payload = $normalized; reason = ""; todoFiles = @()
    }
  }
  $reason = "Codex 종료 코드 $code"
  if (-not $payload) { $reason += " / JSON 해석 실패" }
  $normalizedPayload = $null
  if ($payload) { $normalizedPayload = Normalize-Payload "Codex" $payload }
  return [pscustomobject]@{
    tool = "Codex"; status = "failed"; exitCode = $code; hasUpdates = $false;
    payload = $normalizedPayload; reason = $reason; todoFiles = @()
  }
}

function Invoke-GitFetch {
  Push-Location $RepoRoot
  $prev = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  $previousTerminalPrompt = $env:GIT_TERMINAL_PROMPT
  $previousGcmInteractive = $env:GCM_INTERACTIVE
  try {
    $remotes = @(& git remote 2>$null | Where-Object { $_ })
    if (-not $remotes.Count) {
      Write-Log "Fetch: 원격 없음 - 건너뜀"
      return
    }
    $env:GIT_TERMINAL_PROMPT = "0"
    $env:GCM_INTERACTIVE = "Never"
    & git -c credential.interactive=never -c http.lowSpeedLimit=1 -c http.lowSpeedTime=30 fetch --prune 2>&1 | ForEach-Object {
      $line = $_.ToString().TrimEnd()
      if ($line) { Write-Log ("git fetch: " + $line) }
    }
    $code = $LASTEXITCODE
    Write-Log "Fetch: 완료 (exit $code)"
  } finally {
    if ($null -eq $previousTerminalPrompt) { Remove-Item Env:GIT_TERMINAL_PROMPT -ErrorAction SilentlyContinue } else { $env:GIT_TERMINAL_PROMPT = $previousTerminalPrompt }
    if ($null -eq $previousGcmInteractive) { Remove-Item Env:GCM_INTERACTIVE -ErrorAction SilentlyContinue } else { $env:GCM_INTERACTIVE = $previousGcmInteractive }
    $ErrorActionPreference = $prev
    Pop-Location
  }
}

function Publish-AskTodo {
  $result = [ordered]@{
    requested = $script:publishRequested
    status = "not_started"
    reason = ""
    exitCode = $null
    branch = ""
    commit = ""
    fileCount = 0
  }

  if (-not $script:publishRequested) {
    $result.requested = $false
    $result.status = "skipped"
    $result.reason = "Publish disabled (-NoPublish)."
    $result.exitCode = 0
    return [pscustomobject]$result
  }

  Push-Location $RepoRoot
  $prev = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  try {
    $result.status = "staging"
    & git add ASK Todo 2>&1 | ForEach-Object {
      $line = $_.ToString().TrimEnd()
      if ($line) { Write-Log ("git: " + $line) }
    }
    if ($LASTEXITCODE -ne 0) {
      $result.status = "failed_add"
      $result.exitCode = $LASTEXITCODE
      $result.reason = "git add failed"
      return [pscustomobject]$result
    }

    $staged = @(& git diff --cached --name-only 2>$null)
    if (-not $staged.Count) {
      $result.status = "skipped_no_changes"
      $result.exitCode = 0
      Write-Log "Publish: 변경 없음"
      return [pscustomobject]$result
    }

    $invalid = @($staged | Where-Object { -not (Is-AllowedPath $_) })
    if ($invalid.Count) {
      $result.status = "failed"
      $result.exitCode = 1
      $result.reason = "발행 대상 경로 제한 위반: $($invalid -join ', ')"
      return [pscustomobject]$result
    }

    $result.fileCount = $staged.Count
    $stamp = Get-Date -Format "yyyy-MM-dd HH:mm"
    & git commit -m "chore(asktodo): $repoName ASK/Todo $stamp" 2>&1 | ForEach-Object {
      $line = $_.ToString().TrimEnd()
      if ($line) { Write-Log ("git: " + $line) }
    }
    if ($LASTEXITCODE -ne 0) {
      $result.status = "failed_commit"
      $result.exitCode = $LASTEXITCODE
      $result.reason = "git commit 실패"
      return [pscustomobject]$result
    }

    $branch = (git rev-parse --abbrev-ref HEAD).Trim()
    $result.branch = $branch
    $result.commit = ((git rev-parse HEAD) 2>$null | Select-Object -First 1)
    $remotes = @(& git remote 2>$null)
    if (-not $remotes.Count) {
      $result.status = "committed_no_remote"
      $result.exitCode = 0
      return [pscustomobject]$result
    }

    $result.status = "pull_rebase"
    & git pull --rebase --autostash origin $branch 2>&1 | ForEach-Object {
      $line = $_.ToString().TrimEnd()
      if ($line) { Write-Log ("git: " + $line) }
    }
    if ($LASTEXITCODE -ne 0) {
      $result.status = "failed_pull"
      $result.exitCode = $LASTEXITCODE
      $result.reason = "git pull --rebase 실패"
      return [pscustomobject]$result
    }

    $result.status = "push"
    & git push origin $branch 2>&1 | ForEach-Object {
      $line = $_.ToString().TrimEnd()
      if ($line) { Write-Log ("git: " + $line) }
    }
    $result.exitCode = $LASTEXITCODE
    if ($result.exitCode -ne 0) {
      $result.status = "failed_push"
      $result.reason = "git push 실패"
      return [pscustomobject]$result
    }

    $result.status = "success"
    return [pscustomobject]$result
  } finally {
    $ErrorActionPreference = $prev
    Pop-Location
  }
}

$publishRequested = if ($PSBoundParameters.ContainsKey("Publish")) { [bool]$Publish } else { $false }
if ($PSBoundParameters.ContainsKey("NoPublish")) { $publishRequested = -not [bool]$NoPublish }
$captureRequested = -not $NoCapture

$script:status = [ordered]@{
  repoName = $repoName
  repoPath = $RepoRoot
  repoId = $projectId
  runId = $runId
  tool = $Tool
  logFile = $logFile
  statusFile = $statusFile
  startAt = (Get-Date).ToString("o")
  endAt = $null
  lastRunAt = (Get-Date).ToString("o")
  exitCode = 0
  unauthorizedChanges = @()
  capture = [ordered]@{ requested = $captureRequested; status = "not_started"; reason = ""; hasUpdates = $false; writtenFile = ""; todoFiles = @(); tools = @() }
  publish = [ordered]@{ requested = $publishRequested; status = "not_requested"; reason = ""; branch = ""; commit = ""; fileCount = 0; exitCode = $null }
  result = "unknown"
}

Rotate-LogArtifacts
Write-Log "=== asktodo-capture start (repo=$repoName tool=$Tool run=$runId) ==="
$overallExitCode = 0
$unauthorized = @()
$preStatus = @()

try {
  Ensure-AskTodo
  $preStatus = Get-GitStatusSnapshot

  if (-not $captureRequested) {
    $status.capture.status = "skipped"
    $status.capture.reason = "NoCapture flag"
    Write-Log "Capture: -NoCapture (기록 미생성)"
  } elseif (Test-Paused) {
    $status.capture.status = "skipped"
    $status.capture.reason = "paused"
    Write-Log "Capture: paused (.ask_paused) - 캡처 생략"
  } else {
    Invoke-GitFetch
    $toolRuns = @()
    if ($Tool -eq "claude" -or $Tool -eq "both") { $toolRuns += Invoke-ClaudeCapture }
    if ($Tool -eq "codex" -or $Tool -eq "both") { $toolRuns += Invoke-CodexCapture }
    $status.capture.tools = @($toolRuns)

    $failedTools = @($toolRuns | Where-Object { $_.status -eq "failed" })
    $successfulTools = @($toolRuns | Where-Object { $_.status -eq "success" })
    $hasUpdatePayloads = @($toolRuns | Where-Object { $_.payload -and $_.payload.hasUpdates })

    $status.capture.hasUpdates = [bool]$hasUpdatePayloads.Count
    if ($failedTools.Count) {
      $status.capture.status = "failed"
      $status.capture.reason = ("{0} tool(s) failed: {1}" -f $failedTools.Count, (($failedTools | ForEach-Object { $_.reason }) -join " / "))
      $overallExitCode = 1
    } elseif (-not $successfulTools.Count) {
      $status.capture.status = "failed"
      $status.capture.reason = "요청한 캡처 도구를 실행할 수 없습니다."
      $overallExitCode = 1
    } else {
      if ($hasUpdatePayloads.Count) {
        $writeResult = Write-AiRecord ($hasUpdatePayloads | ForEach-Object { $_.payload })
        if ($writeResult.written) {
          $status.capture.status = "success"
          $status.capture.writtenFile = $writeResult.file
          $status.capture.todoFiles = @($writeResult.todoFiles)
          Write-Log ("Capture: ASK 기록 생성 " + $writeResult.file)
        } else {
          $status.capture.status = "skipped_no_updates"
          $status.capture.reason = "has_updates false"
        }
      } else {
        $status.capture.status = "no_updates"
        $status.capture.reason = "오늘 기록할 변경 근거 없음"
      }
    }
  }

  if ($publishRequested) {
    $status.publish = Publish-AskTodo
    if ($status.publish.status -eq "failed" -or $status.publish.status -eq "failed_commit" -or $status.publish.status -eq "failed_pull" -or $status.publish.status -eq "failed_push") {
      $overallExitCode = 1
    }
    Write-Log ("Publish: " + $status.publish.status + " (exit " + $status.publish.exitCode + ")")
  } else {
    $status.publish.status = "skipped"
    $status.publish.reason = "Publish 기본 비활성. -Publish 지정 시에만 실행."
  }

  $postStatus = Get-GitStatusSnapshot
  $unauthorized = Get-UnauthorizedChanges $preStatus $postStatus
  if ($unauthorized.Count) {
    $overallExitCode = 1
    $status.capture.status = "failed"
    $status.capture.reason = ("허용되지 않은 변경 감지: " + ($unauthorized -join ", "))
    Write-Log "ERROR: " + $status.capture.reason
  }

  $status.unauthorizedChanges = @($unauthorized)
  $status.result = if ($overallExitCode -eq 0) { "success" } else { "failed" }
} catch {
  $overallExitCode = 1
  $status.result = "failed"
  $status.capture.status = "failed"
  $status.capture.reason = $_.Exception.Message
  Write-Log ("ERROR: " + $_.Exception.Message)
} finally {
  $status.endAt = (Get-Date).ToString("o")
  $status.lastRunAt = $status.endAt
  $status.exitCode = $overallExitCode
  Write-Status ($status)
  Write-Log "=== asktodo-capture end ==="
  Write-Host "[DONE] asktodo-capture ($repoName). log: $logFile"
  exit $overallExitCode
}
