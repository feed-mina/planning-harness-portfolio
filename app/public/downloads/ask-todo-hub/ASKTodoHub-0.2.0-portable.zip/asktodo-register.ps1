﻿<#
  asktodo-register.ps1  (ASK/Todo 등록/해제 — Phase 2)

  프로젝트 폴더를 ASK/Todo 자동화에 등록/해제하고 registry.json 을 관리한다.
  등록 = ASK/Todo 폴더 생성(템플릿) + Windows 스케줄 태스크 'ASKTodo - <project>' + registry 항목.
  해제 = 스케줄 태스크 제거 + registry 항목 제거 (ASK/Todo 데이터는 보존).

  사용:
    # 등록 (기본 Claude, 매일 17:30)
    powershell -File asktodo-register.ps1 -Action add -RepoRoot "D:\myproj"
    powershell -File asktodo-register.ps1 -Action add -RepoRoot "D:\myproj" -Tool both -Times 09:00,13:00,18:00
    # 해제
    powershell -File asktodo-register.ps1 -Action remove -RepoRoot "D:\myproj"
    # 목록
    powershell -File asktodo-register.ps1 -Action list
    powershell -File asktodo-register.ps1 -Action rebuild-tasks
  파라미터:
    -Action add|remove|list|rebuild-tasks   (기본 add)
    -RepoRoot <path>          add/remove 시 대상 저장소
    -Tool claude|codex|both   (기본 claude)
    -Time HH:mm               v1 호환용 단일 실행 시각
    -Times HH:mm[]            (기본 17:30) 일일 실행 시각 목록, 최대 12개
#>
[CmdletBinding()]
param(
  [ValidateSet("add", "remove", "list", "validate-times", "audit-tasks", "sanitize-tasks", "rebuild-tasks")][string]$Action = "add",
  [string]$RepoRoot,
  [ValidateSet("claude", "codex", "both")][string]$Tool = "claude",
  [string]$Time,
  [string[]]$Times = @("17:30"),
  [ValidateSet("personal", "temporary")][string]$InstallMode
)

$ErrorActionPreference = "Stop"
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

function Resolve-HubRoot {
  if ($PSScriptRoot) { return (Resolve-Path -LiteralPath $PSScriptRoot).Path }
  if ($PSCommandPath) { return (Split-Path -Parent (Resolve-Path -LiteralPath $PSCommandPath).Path) }
  return (Get-Location).Path
}

$hubRoot     = Resolve-HubRoot
$captureScript = Join-Path $hubRoot "asktodo-capture.ps1"
$registryPath  = Join-Path $hubRoot "registry.json"
$utf8 = New-Object System.Text.UTF8Encoding($false)

function Read-Registry {
  if (Test-Path $registryPath) {
    try {
      $obj = Get-Content -Raw -LiteralPath $registryPath | ConvertFrom-Json
      $projects = @()
      if ($obj.projects) { $projects = @($obj.projects) }
      $version = if ($obj.version) { [int]$obj.version } else { 1 }
      if ($version -gt 2) { throw "지원하지 않는 registry version입니다: $version" }
      if ($version -lt 2) {
        $backup = "$registryPath.v1.bak"
        if (-not (Test-Path -LiteralPath $backup)) { Copy-Item -LiteralPath $registryPath -Destination $backup }
        foreach ($project in $projects) {
          $legacyTime = if ($project.time) { [string]$project.time } else { "17:30" }
          $project | Add-Member -NotePropertyName times -NotePropertyValue @($legacyTime) -Force
          $project | Add-Member -NotePropertyName enabled -NotePropertyValue $true -Force
          $project | Add-Member -NotePropertyName mode -NotePropertyValue "personal" -Force
          $project | Add-Member -NotePropertyName schedule -NotePropertyValue ([pscustomobject]@{
            days = @("daily"); timeZone = "WindowsLocal"; startWhenAvailable = $true
          }) -Force
        }
      }
      $registry = [pscustomobject]@{ version = 2; installMode = $(if ($obj.installMode) { [string]$obj.installMode } else { "personal" }); projects = $projects }
      if ($version -lt 2) { Write-Registry $registry }
      return $registry
    } catch { throw "registry.json 파싱/마이그레이션 실패: $($_.Exception.Message)" }
  }
  return [pscustomobject]@{ version = 2; installMode = "personal"; projects = @() }
}

function Write-Registry($reg) {
  $reg.projects = @($reg.projects)   # 단일 항목이 배열로 유지되도록 강제
  $json = $reg | ConvertTo-Json -Depth 6
  [System.IO.File]::WriteAllText($registryPath, $json, $utf8)
}

function Task-Name([string]$name) { return "ASKTodo - $name" }

function New-SafeTaskPrincipal {
  return New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType S4U -RunLevel Limited
}

function Join-TaskArgument([string]$RepoRoot, [string]$Tool) {
  return '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -RepoRoot "{1}" -Tool {2} -NoPublish' -f $captureScript, $RepoRoot, $Tool
}

function Resolve-TaskLogonType([string]$TaskName) {
  if ([string]::IsNullOrWhiteSpace($TaskName)) { return "" }
  try {
    $task = Get-ScheduledTask -TaskName $TaskName -ErrorAction SilentlyContinue
    if (-not $task -or -not $task.Principal -or -not $task.Principal.LogonType) { return "" }
    return [string]$task.Principal.LogonType
  } catch {
    return ""
  }
}

function Get-AllAskTodoTasks() {
  try {
    return @(
      Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object {
        $_.TaskName -like "ASKTodo - *"
      }
    )
  } catch {
    return @()
  }
}

function Is-InteractiveTask([string]$TaskName) {
  $logonType = Resolve-TaskLogonType $TaskName
  return $logonType -in @("Interactive", "InteractiveToken", "InteractiveTokenOrPassword")
}

function New-TaskSettings() {
  return New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 45) `
    -RestartCount 1 -RestartInterval (New-TimeSpan -Minutes 5)
}

function Register-ProjectTask([string]$RepoRoot, [string]$TaskName, [string]$Tool, [string[]]$Times) {
  $ps = (Get-Command powershell.exe -ErrorAction SilentlyContinue).Source
  if (-not $ps) {
    $root = if ($env:SystemRoot) { $env:SystemRoot } else { "C:\Windows" }
    $ps = Join-Path $root "System32\WindowsPowerShell\v1.0\powershell.exe"
  }
  $arg = Join-TaskArgument $RepoRoot $Tool
  $action = New-ScheduledTaskAction -Execute $ps -Argument $arg -WorkingDirectory $RepoRoot
  $triggers = @($Times | ForEach-Object { New-ScheduledTaskTrigger -Daily -At $_ })
  $settings = New-TaskSettings
  $principal = New-SafeTaskPrincipal
  Register-ScheduledTask -TaskName $TaskName -Action $action -Trigger $triggers -Settings $settings `
    -Principal $principal -Description "ASK/Todo daily capture for $(Split-Path -Leaf $RepoRoot) ($Tool)" -Force | Out-Null
}

function Normalize-ProjectTimes([pscustomobject]$Project) {
  if ($Project.times) { return @($Project.times) }
  if ($Project.time) { return @([string]$Project.time) }
  return @("17:30")
}

function Normalize-Times([string[]]$Values) {
  $normalized = @()
  foreach ($rawValue in @($Values)) {
    foreach ($value in @([string]$rawValue -split ',')) {
    if ([string]::IsNullOrWhiteSpace($value)) { continue }
    $parsed = [datetime]::MinValue
    if (-not [datetime]::TryParseExact($value.Trim(), "HH:mm", [Globalization.CultureInfo]::InvariantCulture,
      [Globalization.DateTimeStyles]::None, [ref]$parsed)) {
      throw "잘못된 실행 시각입니다: '$value' (HH:mm 형식 필요)"
    }
    $normalized += $parsed.ToString("HH:mm")
    }
  }
  $normalized = @($normalized | Sort-Object -Unique)
  if ($normalized.Count -lt 1) { throw "실행 시각은 최소 1개가 필요합니다." }
  if ($normalized.Count -gt 12) { throw "실행 시각은 최대 12개까지 등록할 수 있습니다." }
  return $normalized
}

# --------------------------------------------------------------------------- #
function Do-Add {
  if (-not $RepoRoot) { throw "-RepoRoot 가 필요합니다." }
  $RepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path
  if (-not (Test-Path (Join-Path $RepoRoot ".git"))) { throw "git 저장소가 아닙니다: $RepoRoot" }
  if (-not (Test-Path $captureScript)) { throw "캡처 스크립트 없음: $captureScript" }
  $requestedTimes = if ($PSBoundParameters.ContainsKey("Time")) { @($Time) } else { @($Times) }
  $normalizedTimes = @(Normalize-Times $requestedTimes)
  $name     = Split-Path -Leaf $RepoRoot
  $taskName = Task-Name $name
  $reg = Read-Registry
  $effectiveMode = if ($PSBoundParameters.ContainsKey("InstallMode")) { $InstallMode } elseif ($reg.installMode) { [string]$reg.installMode } else { "personal" }

  # 1) ASK/Todo 폴더 + README (템플릿)
  foreach ($pair in @(@{ Dir = "ASK"; Tpl = "ASK-README.md" }, @{ Dir = "Todo"; Tpl = "Todo-README.md" })) {
    $dir = Join-Path $RepoRoot $pair.Dir
    if (-not (Test-Path $dir)) {
      New-Item -ItemType Directory -Force -Path $dir | Out-Null
      $tpl = Join-Path $hubRoot ("templates\" + $pair.Tpl)
      if (Test-Path $tpl) { Copy-Item $tpl (Join-Path $dir "README.md") -Force }
      Write-Host "  [+] $($pair.Dir)/ 생성"
    }
  }

  # 2) Windows 스케줄 태스크 (temporary mode never persists a task)
  if ($effectiveMode -eq "personal") {
    Register-ProjectTask -RepoRoot $RepoRoot -TaskName $taskName -Tool $Tool -Times $normalizedTimes
    Write-Host "  [+] 스케줄 태스크 '$taskName' 등록 (매일 $($normalizedTimes -join ', '))"
  } else {
    $existingTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if ($existingTask) { Unregister-ScheduledTask -TaskName $taskName -Confirm:$false }
    Write-Host "  [i] 임시 모드: 영구 예약 작업을 만들지 않습니다."
  }

  # 3) registry 갱신 (같은 name/path 는 교체)
  $reg.installMode = $effectiveMode
  $reg.projects = @($reg.projects | Where-Object { $_.name -ne $name -and $_.path -ne $RepoRoot })
  $reg.projects += [pscustomobject]@{
    id = ([Convert]::ToBase64String(([Text.Encoding]::UTF8.GetBytes($RepoRoot.ToLowerInvariant())))).TrimEnd('=').Replace('+','-').Replace('/','_')
    name = $name; path = $RepoRoot; tool = $Tool; times = $normalizedTimes
    schedule = [pscustomobject]@{ days = @("daily"); timeZone = "WindowsLocal"; startWhenAvailable = $true }
    enabled = $true; mode = $effectiveMode; taskName = $(if ($effectiveMode -eq "personal") { $taskName } else { "" }); registeredAt = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
  }
  Write-Registry $reg
  Write-Host "[OK] 등록 완료: $name  ($RepoRoot)"
}

function Do-Remove {
  if (-not $RepoRoot) { throw "-RepoRoot 가 필요합니다." }
  try { $RepoRoot = (Resolve-Path -LiteralPath $RepoRoot).Path } catch {}
  $name     = Split-Path -Leaf $RepoRoot
  $taskName = Task-Name $name

  $t = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
  if ($t) { Unregister-ScheduledTask -TaskName $taskName -Confirm:$false; Write-Host "  [-] 스케줄 태스크 '$taskName' 제거" }
  else    { Write-Host "  [i] 스케줄 태스크 '$taskName' 없음" }

  $reg = Read-Registry
  $before = @($reg.projects).Count
  $reg.projects = @($reg.projects | Where-Object { $_.name -ne $name -and $_.path -ne $RepoRoot })
  Write-Registry $reg
  Write-Host "[OK] 해제 완료: $name (registry $before → $(@($reg.projects).Count)). ASK/Todo 데이터는 보존됨."
}

function Do-List {
  $reg = Read-Registry
  if (-not @($reg.projects).Count) { Write-Host "등록된 프로젝트가 없습니다."; return }
  Write-Host "등록된 프로젝트 ($(@($reg.projects).Count)):"
  foreach ($p in $reg.projects) {
    $t = Get-ScheduledTask -TaskName $p.taskName -ErrorAction SilentlyContinue
    $logonType = if ($t -and $t.Principal -and $t.Principal.LogonType) { [string]$t.Principal.LogonType } else { "" }
    $state = if ($t) { $t.State } else { "(태스크 없음)" }
    $result = ""
    if ($t) {
      $info = Get-ScheduledTaskInfo -TaskName $p.taskName -ErrorAction SilentlyContinue
      if ($info) { $result = " / exit={0}" -f $info.LastTaskResult }
    }
    $interactiveMark = if (Is-InteractiveTask $p.taskName) { " [Interactive]" } else { "" }
    $paused = if ((Test-Path (Join-Path $p.path ".ask_paused")) -or (Test-Path (Join-Path $p.path "scripts\.claude_ask_paused"))) { " [보류]" } else { "" }
    $displayTimes = if ($p.times) { @($p.times) -join "," } elseif ($p.time) { [string]$p.time } else { "" }
    "{0,-22} {1,-8} {2}  {3}{4} {5}{6}{7}" -f $p.name, $p.tool, $displayTimes, $state, $result, $logonType, $interactiveMark, $paused | Write-Host
    "  $($p.path)" | Write-Host
  }
}

function Do-RebuildAllTasks {
  $reg = Read-Registry
  if (-not @($reg.projects).Count) {
    Write-Host "등록된 프로젝트가 없습니다."
    return
  }

  $effectiveMode = if ($reg.installMode) { [string]$reg.installMode } else { "personal" }
  $summary = @{
    processed = 0
    rebuilt   = 0
    skipped   = 0
    failed    = 0
  }

  foreach ($p in @($reg.projects)) {
    $summary.processed++
    $name = if ($p.name) { [string]$p.name } else { Split-Path -Leaf ([string]$p.path) }
    $path = [string]$p.path
    if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path -PathType Container)) {
      Write-Warning "경로 누락/없음으로 스킵: $name -> $path"
      $summary.skipped++
      continue
    }

    $mode = if ($p.mode) { [string]$p.mode } else { $effectiveMode }
    if ($mode -ne "personal") {
      Write-Host "[SKIP] ${name}: mode=${mode} (영구 태스크 생성 안 함)"
      $summary.skipped++
      continue
    }

    $tool = if ($p.tool) { [string]$p.tool } else { "claude" }
    $taskName = if ($p.taskName) { [string]$p.taskName } else { Task-Name (Split-Path -Leaf $path) }
    if ([string]::IsNullOrWhiteSpace($taskName)) { $taskName = Task-Name (Split-Path -Leaf $path) }
    $times = @(Normalize-Times (Normalize-ProjectTimes $p))

    try {
      Register-ProjectTask -RepoRoot $path -TaskName $taskName -Tool $tool -Times $times
      Write-Host ("[OK] {0}: {1}" -f $name, $taskName)
      $summary.rebuilt++
      $p.taskName = $taskName
      $p.tool = $tool
      $p.times = $times
      $p.mode = $mode
    } catch {
      Write-Warning ("[FAIL] {0}: {1}" -f $name, $_.Exception.Message)
      $summary.failed++
    }
  }

  if ($summary.rebuilt -gt 0) { Write-Registry $reg }
  Write-Host ("[DONE] processed={0}, rebuilt={1}, skipped={2}, failed={3}" -f $summary.processed, $summary.rebuilt, $summary.skipped, $summary.failed)
  if ($summary.failed -gt 0) {
    throw ("예약 작업 재생성 실패: {0}개" -f $summary.failed)
  }
}

function Do-AuditTasks {
  $reg = Read-Registry
  if (-not @($reg.projects).Count) { Write-Host "등록된 프로젝트가 없습니다."; return }
  $projectTaskNames = @{}
  foreach ($p in @($reg.projects)) { if ($p.taskName) { $projectTaskNames[[string]$p.taskName] = $true } }

  $allTasks = Get-AllAskTodoTasks
  if ($allTasks.Count) {
    Write-Host "시스템의 모든 ASKTodo 태스크:"
    foreach ($task in $allTasks) {
      $taskName = [string]$task.TaskName
      $logonType = if ($task.Principal -and $task.Principal.LogonType) { [string]$task.Principal.LogonType } else { "(unknown)" }
      $status = if (Is-InteractiveTask $taskName) { "[INTERACTIVE]" } else { "[OK]" }
      $regMarker = if ($projectTaskNames.ContainsKey($taskName)) { "" } else { " [NOT IN REGISTRY]" }
      Write-Host ("{0,-22} {1} {2}{3}" -f $taskName, $status, $logonType, $regMarker)
    }
  } else {
    Write-Host "시스템에서 ASKTodo - * 패턴 태스크를 찾지 못했습니다."
  }

  Write-Host "인터랙티브 태스크 점검:"
  foreach ($p in @($reg.projects)) {
    if ($p.mode -eq "temporary" -or -not $p.taskName) { continue }
    $taskName = [string]$p.taskName
    $t = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if (-not $t) {
      Write-Host ("{0,-22} [MISSING] {1}" -f $p.name, $taskName)
      continue
    }
    $logonType = if ($t.Principal -and $t.Principal.LogonType) { [string]$t.Principal.LogonType } else { "(unknown)" }
    $status = if (Is-InteractiveTask $taskName) { "[INTERACTIVE]" } else { "[OK]" }
    Write-Host ("{0,-22} {1} {2}" -f $p.name, $status, $logonType)
  }
}

function Do-SanitizeTasks {
  $reg = Read-Registry
  if (-not @($reg.projects).Count) { Write-Host "등록된 프로젝트가 없습니다."; return }
  $fixed = 0
  foreach ($p in @($reg.projects)) {
    if ($p.mode -eq "temporary" -or -not $p.taskName) { continue }
    $taskName = [string]$p.taskName
    if (-not (Is-InteractiveTask $taskName)) { continue }
    if (-not (Test-Path -LiteralPath [string]$p.path)) {
      Write-Warning "경로 없음으로 정리 건너뜀: $($p.path)"
      continue
    }
    try {
      $tool = if ($p.tool) { [string]$p.tool } else { "claude" }
      $times = Normalize-Times (Normalize-ProjectTimes $p)
      Register-ProjectTask -RepoRoot ([string]$p.path) -TaskName $taskName -Tool $tool -Times $times
      Write-Host ("[FIX] {0} => S4U" -f $taskName)
      $fixed++
    } catch {
      Write-Warning ("정리 실패: {0} - {1}" -f $taskName, $_.Exception.Message)
    }
  }
  Write-Host "[DONE] interactive 정리: $fixed 개"
}

switch ($Action) {
  "add"    { Do-Add }
  "remove" { Do-Remove }
  "list"   { Do-List }
  "audit-tasks" { Do-AuditTasks }
  "sanitize-tasks" { Do-SanitizeTasks }
  "rebuild-tasks" { Do-RebuildAllTasks }
  "validate-times" { Normalize-Times $(if ($PSBoundParameters.ContainsKey("Time")) { @($Time) } else { @($Times) }) }
}
