
### ASK/Todo 대화 기록 (ask-todo 스킬)
<!-- ask-todo-recognition -->
`ASK/` 폴더가 있는 프로젝트에서 사용자가 "오늘 대화 ASK에 기록/정리", "ASK 로그 남겨줘" 등을 요청하면 **ask-todo 스킬**로 `ASK/YYYY-MM-DD_ai.md`·`Todo/*.md` 에 누적한다. 규칙: git 근거만·추측 금지·append 보존, `.ask_paused` 있으면 건너뜀, 기록 전 `git fetch`. `ASK/` 가 없는 저장소에서는 자동 기록하지 않는다(명시 요청 시 생성만).
