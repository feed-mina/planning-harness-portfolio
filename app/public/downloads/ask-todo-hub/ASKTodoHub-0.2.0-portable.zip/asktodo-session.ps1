﻿<#
  Personal/temporary mode controller and ownership-safe temporary cleanup.

  Cleanup defaults to dry-run. -Execute removes only temporary registry entries,
  Hub task names recorded on those entries, Hub logs, and clone directories that
  contain the .asktodo-owned-temp.json ownership marker.
#>
[CmdletBinding()]
param(
  [ValidateSet("status", "set-personal", "set-temporary", "cleanup")][string]$Action = "status",
  [switch]$Execute,
  [switch]$AsJson
)

$ErrorActionPreference = "Stop"
$hubRoot = if ($PSScriptRoot) { $PSScriptRoot } else { (Get-Location).Path }
$registryPath = Join-Path $hubRoot "registry.json"
$utf8 = New-Object Text.UTF8Encoding($false)

function Get-ProjectId([string]$Path) {
  if ([string]::IsNullOrWhiteSpace($Path)) { return "" }
  return ([Convert]::ToBase64String(([Text.Encoding]::UTF8.GetBytes($Path.ToLowerInvariant())))).TrimEnd('=').Replace('+','-').Replace('/','_')
}

function Read-Registry {
  if (-not (Test-Path -LiteralPath $registryPath)) { return [pscustomobject]@{ version = 2; installMode = "personal"; projects = @() } }
  $registry = Get-Content -Raw -Encoding UTF8 -LiteralPath $registryPath | ConvertFrom-Json
  if ([int]$registry.version -gt 2) { throw "Unsupported registry version: $($registry.version)" }
  if (-not $registry.installMode) { $registry | Add-Member -NotePropertyName installMode -NotePropertyValue "personal" -Force }
  if (-not $registry.projects) { $registry | Add-Member -NotePropertyName projects -NotePropertyValue @() -Force }
  return $registry
}

function Write-Registry($Registry) {
  $Registry.version = 2
  $Registry.projects = @($Registry.projects)
  [IO.File]::WriteAllText($registryPath, ($Registry | ConvertTo-Json -Depth 8), $utf8)
}

function Set-Mode([string]$Mode) {
  $registry = Read-Registry
  $registry.installMode = $Mode
  Write-Registry $registry
  return [pscustomobject]@{ mode = $Mode; changed = $true }
}

function Test-OwnedTemporaryClone([string]$Path) {
  if ([string]::IsNullOrWhiteSpace($Path) -or -not (Test-Path -LiteralPath $Path -PathType Container)) { return $false }
  $markerPath = Join-Path $Path ".asktodo-owned-temp.json"
  if (-not (Test-Path -LiteralPath $markerPath -PathType Leaf)) { return $false }
  try {
    $marker = Get-Content -Raw -Encoding UTF8 -LiteralPath $markerPath | ConvertFrom-Json
    return $marker.owner -eq "ASKTodoHub"
  } catch { return $false }
}

function Get-CleanupPlan {
  $registry = Read-Registry
  $temporaryProjects = @($registry.projects | Where-Object { $_.mode -eq "temporary" })
  return @($temporaryProjects | ForEach-Object {
    $logId = Get-ProjectId $_.path
    $logCandidates = @(
      (Join-Path $hubRoot ("logs\{0}.log" -f $_.name)),
      (Join-Path $hubRoot ("logs\{0}.log" -f $logId)),
      (Join-Path $hubRoot ("logs\{0}.status.json" -f $_.name)),
      (Join-Path $hubRoot ("logs\{0}.status.json" -f $logId))
    )
    [pscustomobject]@{
      name = [string]$_.name
      path = [string]$_.path
      taskName = [string]$_.taskName
      removeOwnedClone = Test-OwnedTemporaryClone ([string]$_.path)
      removeRegistryEntry = $true
      removeLogFiles = $logCandidates | Where-Object { Test-Path -LiteralPath $_ }
    }
  })
}

function Invoke-Cleanup {
  $registry = Read-Registry
  $plan = @(Get-CleanupPlan)
  if (-not $Execute) { return $plan }
  foreach ($item in $plan) {
    if ($item.taskName) {
      try {
        $task = Get-ScheduledTask -TaskName $item.taskName -ErrorAction SilentlyContinue
        if ($task) { Unregister-ScheduledTask -TaskName $item.taskName -Confirm:$false }
      } catch { Write-Warning "Scheduled task cleanup failed for $($item.taskName): $($_.Exception.Message)" }
    }
    foreach ($logPath in @($item.removeLogFiles)) {
      Remove-Item -LiteralPath $logPath -Force -ErrorAction SilentlyContinue
    }
    if ($item.removeOwnedClone -and (Test-OwnedTemporaryClone $item.path)) {
      Remove-Item -LiteralPath $item.path -Recurse -Force
    }
  }
  $temporaryPaths = @($plan | ForEach-Object { $_.path })
  $registry.projects = @($registry.projects | Where-Object { $_.path -notin $temporaryPaths })
  Write-Registry $registry
  return $plan
}

$result = switch ($Action) {
  "status" {
    $registry = Read-Registry
    [pscustomobject]@{ mode = [string]$registry.installMode; temporaryProjects = @($registry.projects | Where-Object { $_.mode -eq "temporary" }).Count }
  }
  "set-personal" { Set-Mode "personal" }
  "set-temporary" { Set-Mode "temporary" }
  "cleanup" { Invoke-Cleanup }
}

if ($AsJson) { $result | ConvertTo-Json -Depth 6 } else { $result }
